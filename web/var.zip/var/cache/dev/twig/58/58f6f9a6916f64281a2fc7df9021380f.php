<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* global/macros.html.twig */
class __TwigTemplate_e77d3e977279560befb21bd3e3cc7a09 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/macros.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/macros.html.twig"));

        // line 18
        yield "
";
        // line 25
        yield "
";
        // line 32
        yield "
";
        // line 39
        yield "
";
        // line 53
        yield "
";
        // line 66
        yield "
";
        // line 74
        yield "
";
        // line 127
        yield "
";
        // line 141
        yield "
";
        // line 148
        yield "
";
        // line 155
        yield "
";
        // line 164
        yield "
";
        // line 175
        yield "
";
        // line 181
        yield "

";
        // line 183
        $macros["macro"] = $this->macros["macro"] = $this;
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 1
    public function macro_alertMessage($__label__ = null, $__messages__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "label" => $__label__,
            "messages" => $__messages__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "alertMessage"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "alertMessage"));

            // line 2
            $context["alertColor"] = "red";
            // line 3
            if (((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 3, $this->source); })()) == "info")) {
                $context["alertColor"] = "ligthBlue";
            }
            // line 4
            if (((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 4, $this->source); })()) == "warning")) {
                $context["alertColor"] = "yellow";
            }
            // line 5
            if (((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 5, $this->source); })()) == "success")) {
                $context["alertColor"] = "green";
            }
            // line 6
            yield "<div class=\"znv-alert znv-";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["alertColor"]) || array_key_exists("alertColor", $context) ? $context["alertColor"] : (function () { throw new RuntimeError('Variable "alertColor" does not exist.', 6, $this->source); })()), "html", null, true);
            yield " alert\" role=\"alert\">
    <button type=\"button\" class=\"znv-close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span></button>
    <strong>";
            // line 8
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(("flash.labels." . (isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 8, $this->source); })())), [], "flashes"), "html", null, true);
            yield "!</strong>
    ";
            // line 9
            if (is_iterable((isset($context["messages"]) || array_key_exists("messages", $context) ? $context["messages"] : (function () { throw new RuntimeError('Variable "messages" does not exist.', 9, $this->source); })()))) {
                // line 10
                yield "        ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable((isset($context["messages"]) || array_key_exists("messages", $context) ? $context["messages"] : (function () { throw new RuntimeError('Variable "messages" does not exist.', 10, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                    // line 11
                    yield "            ";
                    yield $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["message"], [], "flashes");
                    yield " <br>
        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 13
                yield "    ";
            } else {
                // line 14
                yield "        ";
                yield $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["messages"]) || array_key_exists("messages", $context) ? $context["messages"] : (function () { throw new RuntimeError('Variable "messages" does not exist.', 14, $this->source); })()), [], "flashes");
                yield " <br>
    ";
            }
            // line 16
            yield "</div>
";
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 19
    public function macro_buttonReturn($__path__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "path" => $__path__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "buttonReturn"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "buttonReturn"));

            // line 20
            yield "    <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["path"]) || array_key_exists("path", $context) ? $context["path"] : (function () { throw new RuntimeError('Variable "path" does not exist.', 20, $this->source); })()), "html", null, true);
            yield "\" class=\"znv-btn\">
        <i class=\"fa-arrow-left\"></i>
        ";
            // line 22
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::upper($this->env->getCharset(), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("form.buttons.return")), "html", null, true);
            yield "
    </a>
";
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 26
    public function macro_listActionButton($__path__ = null, $__title__ = null, $__icon__ = null, $__roles__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "path" => $__path__,
            "title" => $__title__,
            "icon" => $__icon__,
            "roles" => $__roles__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "listActionButton"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "listActionButton"));

            // line 27
            yield "    ";
            if ((( !Twig\Extension\CoreExtension::testEmpty((isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 27, $this->source); })())) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 27, $this->source); })()), "user", [], "any", false, false, false, 27), "hasRole", [(isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 27, $this->source); })())], "method", false, false, false, 27)) || Twig\Extension\CoreExtension::testEmpty((isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 27, $this->source); })())))) {
                // line 28
                yield "        <a href=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["path"]) || array_key_exists("path", $context) ? $context["path"] : (function () { throw new RuntimeError('Variable "path" does not exist.', 28, $this->source); })()), "html", null, true);
                yield "\" rel=\"tooltip\" data-placement=\"bottom\" data-original-title=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 28, $this->source); })())), "html", null, true);
                yield "\"
               class=\"znv-icon ";
                // line 29
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 29, $this->source); })()), "html", null, true);
                yield "\"></a>
    ";
            }
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 33
    public function macro_listActionButtonSpan($__path__ = null, $__title__ = null, $__spanClass__ = null, $__spanText__ = null, $__roles__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "path" => $__path__,
            "title" => $__title__,
            "spanClass" => $__spanClass__,
            "spanText" => $__spanText__,
            "roles" => $__roles__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "listActionButtonSpan"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "listActionButtonSpan"));

            // line 34
            yield "    ";
            if ((( !Twig\Extension\CoreExtension::testEmpty((isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 34, $this->source); })())) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 34, $this->source); })()), "user", [], "any", false, false, false, 34), "hasRole", [(isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 34, $this->source); })())], "method", false, false, false, 34)) || Twig\Extension\CoreExtension::testEmpty((isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 34, $this->source); })())))) {
                // line 35
                yield "        <a href=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["path"]) || array_key_exists("path", $context) ? $context["path"] : (function () { throw new RuntimeError('Variable "path" does not exist.', 35, $this->source); })()), "html", null, true);
                yield "\" rel=\"tooltip\" data-placement=\"bottom\" data-original-title=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 35, $this->source); })())), "html", null, true);
                yield "\">
        <span class=\"znv-label ";
                // line 36
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["spanClass"]) || array_key_exists("spanClass", $context) ? $context["spanClass"] : (function () { throw new RuntimeError('Variable "spanClass" does not exist.', 36, $this->source); })()), "html", null, true);
                yield "\">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::upper($this->env->getCharset(), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["spanText"]) || array_key_exists("spanText", $context) ? $context["spanText"] : (function () { throw new RuntimeError('Variable "spanText" does not exist.', 36, $this->source); })()))), "html", null, true);
                yield "</span></a>
    ";
            }
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 40
    public function macro_liConfirmButton($__title__ = null, $__classIcon__ = null, $__roles__ = null, $__callback__ = null, $__modalId__ = null, $__selector__ = null, $__path__ = null, $__dataExtraBody__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "title" => $__title__,
            "classIcon" => $__classIcon__,
            "roles" => $__roles__,
            "callback" => $__callback__,
            "modalId" => $__modalId__,
            "selector" => $__selector__,
            "path" => $__path__,
            "dataExtraBody" => $__dataExtraBody__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "liConfirmButton"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "liConfirmButton"));

            // line 41
            yield "    ";
            $context["selector"] = ((((isset($context["selector"]) || array_key_exists("selector", $context) ? $context["selector"] : (function () { throw new RuntimeError('Variable "selector" does not exist.', 41, $this->source); })()) == "")) ? ("div.znv-line") : ((isset($context["selector"]) || array_key_exists("selector", $context) ? $context["selector"] : (function () { throw new RuntimeError('Variable "selector" does not exist.', 41, $this->source); })())));
            // line 42
            yield "    ";
            $context["modalId"] = ((((isset($context["modalId"]) || array_key_exists("modalId", $context) ? $context["modalId"] : (function () { throw new RuntimeError('Variable "modalId" does not exist.', 42, $this->source); })()) == "")) ? ("modalConfirm") : ((isset($context["modalId"]) || array_key_exists("modalId", $context) ? $context["modalId"] : (function () { throw new RuntimeError('Variable "modalId" does not exist.', 42, $this->source); })())));
            // line 43
            yield "    ";
            $context["callback"] = ((((isset($context["callback"]) || array_key_exists("callback", $context) ? $context["callback"] : (function () { throw new RuntimeError('Variable "callback" does not exist.', 43, $this->source); })()) == "")) ? ("undefined") : ((isset($context["callback"]) || array_key_exists("callback", $context) ? $context["callback"] : (function () { throw new RuntimeError('Variable "callback" does not exist.', 43, $this->source); })())));
            // line 44
            yield "    ";
            $context["path"] = ((((isset($context["path"]) || array_key_exists("path", $context) ? $context["path"] : (function () { throw new RuntimeError('Variable "path" does not exist.', 44, $this->source); })()) == "")) ? ("undefined") : ((isset($context["path"]) || array_key_exists("path", $context) ? $context["path"] : (function () { throw new RuntimeError('Variable "path" does not exist.', 44, $this->source); })())));
            // line 45
            yield "    ";
            $context["dataExtraBody"] = ((((isset($context["dataExtraBody"]) || array_key_exists("dataExtraBody", $context) ? $context["dataExtraBody"] : (function () { throw new RuntimeError('Variable "dataExtraBody" does not exist.', 45, $this->source); })()) == "")) ? ("undefined") : ((isset($context["dataExtraBody"]) || array_key_exists("dataExtraBody", $context) ? $context["dataExtraBody"] : (function () { throw new RuntimeError('Variable "dataExtraBody" does not exist.', 45, $this->source); })())));
            // line 46
            yield "    ";
            if ((( !Twig\Extension\CoreExtension::testEmpty((isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 46, $this->source); })())) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 46, $this->source); })()), "user", [], "any", false, false, false, 46), "hasRole", [(isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 46, $this->source); })())], "method", false, false, false, 46)) || Twig\Extension\CoreExtension::testEmpty((isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 46, $this->source); })())))) {
                // line 47
                yield "            <button type=\"button\" data-rel=\"tooltip\" data-placement=\"top\" title=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 47, $this->source); })())), "html", null, true);
                yield "\"
                    data-toggle=\"modal\" class=\"";
                // line 48
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["classIcon"]) || array_key_exists("classIcon", $context) ? $context["classIcon"] : (function () { throw new RuntimeError('Variable "classIcon" does not exist.', 48, $this->source); })()), "html", null, true);
                yield "\"
                    data-target=\"#";
                // line 49
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["modalId"]) || array_key_exists("modalId", $context) ? $context["modalId"] : (function () { throw new RuntimeError('Variable "modalId" does not exist.', 49, $this->source); })()), "html", null, true);
                yield "\" onclick=\"show";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["modalId"]) || array_key_exists("modalId", $context) ? $context["modalId"] : (function () { throw new RuntimeError('Variable "modalId" does not exist.', 49, $this->source); })()), "html", null, true);
                yield "(this, ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["callback"]) || array_key_exists("callback", $context) ? $context["callback"] : (function () { throw new RuntimeError('Variable "callback" does not exist.', 49, $this->source); })()), "html", null, true);
                yield ",'";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["selector"]) || array_key_exists("selector", $context) ? $context["selector"] : (function () { throw new RuntimeError('Variable "selector" does not exist.', 49, $this->source); })()), "html", null, true);
                yield "', '";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["path"]) || array_key_exists("path", $context) ? $context["path"] : (function () { throw new RuntimeError('Variable "path" does not exist.', 49, $this->source); })()), "html", null, true);
                yield "', '";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["dataExtraBody"]) || array_key_exists("dataExtraBody", $context) ? $context["dataExtraBody"] : (function () { throw new RuntimeError('Variable "dataExtraBody" does not exist.', 49, $this->source); })()), "html", null, true);
                yield "')\">
            </button>
    ";
            }
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 54
    public function macro_liConfirmButtonComercio($__title__ = null, $__color__ = null, $__action__ = null, $__text__ = null, $__roles__ = null, $__callback__ = null, $__modalId__ = null, $__selector__ = null, $__path__ = null, $__dataExtraBody__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "title" => $__title__,
            "color" => $__color__,
            "action" => $__action__,
            "text" => $__text__,
            "roles" => $__roles__,
            "callback" => $__callback__,
            "modalId" => $__modalId__,
            "selector" => $__selector__,
            "path" => $__path__,
            "dataExtraBody" => $__dataExtraBody__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "liConfirmButtonComercio"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "liConfirmButtonComercio"));

            // line 55
            yield "    ";
            $context["selector"] = ((((isset($context["selector"]) || array_key_exists("selector", $context) ? $context["selector"] : (function () { throw new RuntimeError('Variable "selector" does not exist.', 55, $this->source); })()) == "")) ? ("div.znv-line") : ((isset($context["selector"]) || array_key_exists("selector", $context) ? $context["selector"] : (function () { throw new RuntimeError('Variable "selector" does not exist.', 55, $this->source); })())));
            // line 56
            yield "    ";
            $context["modalId"] = ((((isset($context["modalId"]) || array_key_exists("modalId", $context) ? $context["modalId"] : (function () { throw new RuntimeError('Variable "modalId" does not exist.', 56, $this->source); })()) == "")) ? ("modalConfirm") : ((isset($context["modalId"]) || array_key_exists("modalId", $context) ? $context["modalId"] : (function () { throw new RuntimeError('Variable "modalId" does not exist.', 56, $this->source); })())));
            // line 57
            yield "    ";
            $context["callback"] = ((((isset($context["callback"]) || array_key_exists("callback", $context) ? $context["callback"] : (function () { throw new RuntimeError('Variable "callback" does not exist.', 57, $this->source); })()) == "")) ? ("undefined") : ((isset($context["callback"]) || array_key_exists("callback", $context) ? $context["callback"] : (function () { throw new RuntimeError('Variable "callback" does not exist.', 57, $this->source); })())));
            // line 58
            yield "    ";
            $context["path"] = ((((isset($context["path"]) || array_key_exists("path", $context) ? $context["path"] : (function () { throw new RuntimeError('Variable "path" does not exist.', 58, $this->source); })()) == "")) ? ("undefined") : ((isset($context["path"]) || array_key_exists("path", $context) ? $context["path"] : (function () { throw new RuntimeError('Variable "path" does not exist.', 58, $this->source); })())));
            // line 59
            yield "    ";
            $context["dataExtraBody"] = ((((isset($context["dataExtraBody"]) || array_key_exists("dataExtraBody", $context) ? $context["dataExtraBody"] : (function () { throw new RuntimeError('Variable "dataExtraBody" does not exist.', 59, $this->source); })()) == "")) ? ("undefined") : ((isset($context["dataExtraBody"]) || array_key_exists("dataExtraBody", $context) ? $context["dataExtraBody"] : (function () { throw new RuntimeError('Variable "dataExtraBody" does not exist.', 59, $this->source); })())));
            // line 60
            yield "    ";
            if ((( !Twig\Extension\CoreExtension::testEmpty((isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 60, $this->source); })())) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 60, $this->source); })()), "user", [], "any", false, false, false, 60), "hasRole", [(isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 60, $this->source); })())], "method", false, false, false, 60)) || Twig\Extension\CoreExtension::testEmpty((isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 60, $this->source); })())))) {
                // line 61
                yield "        <button type=\"button\" data-rel=\"tooltip\" data-placement=\"top\" title=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 61, $this->source); })()), "html", null, true);
                yield "\"
                class=\"znv-btn\" data-toggle=\"modal\" data-target=\"#";
                // line 62
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["modalId"]) || array_key_exists("modalId", $context) ? $context["modalId"] : (function () { throw new RuntimeError('Variable "modalId" does not exist.', 62, $this->source); })()), "html", null, true);
                yield "\" onclick=\"show";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["modalId"]) || array_key_exists("modalId", $context) ? $context["modalId"] : (function () { throw new RuntimeError('Variable "modalId" does not exist.', 62, $this->source); })()), "html", null, true);
                yield "(this, ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["callback"]) || array_key_exists("callback", $context) ? $context["callback"] : (function () { throw new RuntimeError('Variable "callback" does not exist.', 62, $this->source); })()), "html", null, true);
                yield ",'";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["selector"]) || array_key_exists("selector", $context) ? $context["selector"] : (function () { throw new RuntimeError('Variable "selector" does not exist.', 62, $this->source); })()), "html", null, true);
                yield "', '";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["path"]) || array_key_exists("path", $context) ? $context["path"] : (function () { throw new RuntimeError('Variable "path" does not exist.', 62, $this->source); })()), "html", null, true);
                yield "', '";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["dataExtraBody"]) || array_key_exists("dataExtraBody", $context) ? $context["dataExtraBody"] : (function () { throw new RuntimeError('Variable "dataExtraBody" does not exist.', 62, $this->source); })()), "html", null, true);
                yield "')\"><span class=\"znv-label ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 62, $this->source); })()), "html", null, true);
                yield "\">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["action"]) || array_key_exists("action", $context) ? $context["action"] : (function () { throw new RuntimeError('Variable "action" does not exist.', 62, $this->source); })()), "html", null, true);
                yield "</span> ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["text"]) || array_key_exists("text", $context) ? $context["text"] : (function () { throw new RuntimeError('Variable "text" does not exist.', 62, $this->source); })()), "html", null, true);
                yield "
        </button>
    ";
            }
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 67
    public function macro_listEmpty($__totalEntitiesCount__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "totalEntitiesCount" => $__totalEntitiesCount__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "listEmpty"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "listEmpty"));

            // line 68
            yield "    ";
            if (((isset($context["totalEntitiesCount"]) || array_key_exists("totalEntitiesCount", $context) ? $context["totalEntitiesCount"] : (function () { throw new RuntimeError('Variable "totalEntitiesCount" does not exist.', 68, $this->source); })()) == 0)) {
                // line 69
                yield "        <div class=\"boxListEmpty\">
            <p>";
                // line 70
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::upper($this->env->getCharset(), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.list.empty")), "html", null, true);
                yield "</p>
        </div>
    ";
            }
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 75
    public function macro_modal($__label__ = null, $__body__ = null, $__icon__ = null, $__modalClass__ = null, $__id__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "label" => $__label__,
            "body" => $__body__,
            "icon" => $__icon__,
            "modalClass" => $__modalClass__,
            "id" => $__id__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "modal"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "modal"));

            // line 76
            yield "    ";
            $context["id"] = ((((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 76, $this->source); })()) == "")) ? ("modalConfirm") : ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 76, $this->source); })())));
            // line 77
            yield "    <div class=\"znv-modal ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["modalClass"]) || array_key_exists("modalClass", $context) ? $context["modalClass"] : (function () { throw new RuntimeError('Variable "modalClass" does not exist.', 77, $this->source); })()), "html", null, true);
            yield " in\" id=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 77, $this->source); })()), "html", null, true);
            yield "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"delete\">
        <div class=\"znv-modal-dialog\" role=\"document\">
            <div class=\"znv-modal-content\">
                <div class=\"znv-modal-header\">
                    <button type=\"button\" class=\"znv-close\" data-dismiss=\"modal\">
                        <span aria-hidden=\"true\">×</span>
                    </button>
                    <div class=\"znv-icon ";
            // line 84
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("icon", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 84, $this->source); })()), "fa-trash")) : ("fa-trash")), "html", null, true);
            yield "\"></div>
                    <span class=\"js-modal-label\">";
            // line 85
            yield $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 85, $this->source); })()));
            yield "</span>
                </div>
                <div class=\"znv-modal-body\">
                    <p class=\"js-modal-body\">";
            // line 88
            yield $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["body"]) || array_key_exists("body", $context) ? $context["body"] : (function () { throw new RuntimeError('Variable "body" does not exist.', 88, $this->source); })()));
            yield "<span class=\"js-modal-extra-body\"></span></p>
                </div>
                <div class=\"znv-modal-footer\">
                    <button type=\"button\" class=\"znv-btn znv-greyDark\" data-dismiss=\"modal\">
                        ";
            // line 92
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::upper($this->env->getCharset(), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("form.buttons.cancel")), "html", null, true);
            yield "
                        <div class=\"ripple-container\">
                            <div class=\"ripple ripple-on ripple-out\"
                                 style=\"left: 16.0313px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(10.375);\"></div>
                        </div>
                    </button>
                    <button type=\"submit\" class=\"znv-btn znv-greenDark js-modal-accept\">
                        ";
            // line 99
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::upper($this->env->getCharset(), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("form.buttons.accept_modal")), "html", null, true);
            yield "
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function show";
            // line 107
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 107, $this->source); })()), "html", null, true);
            yield "(button, callback, selector, path, dataExtraBody) {
            ";
            // line 108
            if ( !array_key_exists("selector", $context)) {
                yield " ";
                $context["selector"] = "div.znv-line";
                yield " ";
            }
            // line 109
            yield "            if (typeof callback !== 'undefined') {
                callback(button);
            }

            var \$modal = \$('#";
            // line 113
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 113, $this->source); })()), "html", null, true);
            yield "');
            var \$button = \$(button);
            var \$div = \$button.parents(selector);
            if( path !== 'undefined'){
                \$path = path;
            }else{
                \$path = \$div.data('path');
            }
            \$modal.find('.js-modal-extra-body').html (' '+ dataExtraBody);
            \$modal.find('.js-modal-accept').click(function(){window.location=\$path});

        }
    </script>
";
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 128
    public function macro_liNav($__active__ = null, $__route__ = null, $__linkText__ = null, $__roles__ = null, $__icon__ = null, $__routeParams__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "active" => $__active__,
            "route" => $__route__,
            "linkText" => $__linkText__,
            "roles" => $__roles__,
            "icon" => $__icon__,
            "routeParams" => $__routeParams__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "liNav"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "liNav"));

            // line 129
            if ((null === (isset($context["routeParams"]) || array_key_exists("routeParams", $context) ? $context["routeParams"] : (function () { throw new RuntimeError('Variable "routeParams" does not exist.', 129, $this->source); })()))) {
                $context["routeParams"] = [];
            }
            // line 130
            $context["classIcon"] = "";
            // line 131
            yield "    ";
            if ((array_key_exists("icon", $context) && ((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 131, $this->source); })()) != ""))) {
                $context["classIcon"] = ("znv-icon " . (isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 131, $this->source); })()));
            }
            // line 132
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 132, $this->source); })()), "user", [], "any", false, false, false, 132), "hasRole", [(isset($context["roles"]) || array_key_exists("roles", $context) ? $context["roles"] : (function () { throw new RuntimeError('Variable "roles" does not exist.', 132, $this->source); })())], "method", false, false, false, 132)) {
                // line 133
                yield "        <li ";
                if ((isset($context["active"]) || array_key_exists("active", $context) ? $context["active"] : (function () { throw new RuntimeError('Variable "active" does not exist.', 133, $this->source); })())) {
                    yield " class=\"znv-active\" ";
                }
                yield ">
            <a href=\"";
                // line 134
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath((isset($context["route"]) || array_key_exists("route", $context) ? $context["route"] : (function () { throw new RuntimeError('Variable "route" does not exist.', 134, $this->source); })()), (isset($context["routeParams"]) || array_key_exists("routeParams", $context) ? $context["routeParams"] : (function () { throw new RuntimeError('Variable "routeParams" does not exist.', 134, $this->source); })())), "html", null, true);
                yield "\" class=\"znv-btn\">
                <div class=\"";
                // line 135
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["classIcon"]) || array_key_exists("classIcon", $context) ? $context["classIcon"] : (function () { throw new RuntimeError('Variable "classIcon" does not exist.', 135, $this->source); })()), "html", null, true);
                yield "\"></div>
                ";
                // line 136
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["linkText"]) || array_key_exists("linkText", $context) ? $context["linkText"] : (function () { throw new RuntimeError('Variable "linkText" does not exist.', 136, $this->source); })()), "html", null, true);
                yield "
            </a>
        </li>
    ";
            }
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 142
    public function macro_cardHalfView($__text__ = null, $__value__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "text" => $__text__,
            "value" => $__value__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "cardHalfView"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "cardHalfView"));

            // line 143
            yield "<div class=\"znv-form-group-view\">
    <p>";
            // line 144
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["text"]) || array_key_exists("text", $context) ? $context["text"] : (function () { throw new RuntimeError('Variable "text" does not exist.', 144, $this->source); })()), "html", null, true);
            yield "</p>
    <h3>";
            // line 145
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("value", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 145, $this->source); })()), " ---- ")) : (" ---- ")), "html", null, true);
            yield "</h3>
</div>
";
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 149
    public function macro_viewHeaderFields($__title__ = null, $__icon__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "title" => $__title__,
            "icon" => $__icon__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "viewHeaderFields"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "viewHeaderFields"));

            // line 150
            yield "<div class=\"znv-widgets-header\">
    <div class=\"znv-icon ";
            // line 151
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 151, $this->source); })()), "html", null, true);
            yield "\"></div>
    <h3>";
            // line 152
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 152, $this->source); })()), "html", null, true);
            yield "</h3>
</div><!-- znv-widgets-header -->
";
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 156
    public function macro_viewField($__label__ = null, $__value__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "label" => $__label__,
            "value" => $__value__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "viewField"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "viewField"));

            // line 157
            yield "<div class=\"znv-form-group-view\">
    <p>";
            // line 158
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 158, $this->source); })()), "html", null, true);
            yield "</p>
    <div class=\"znv-group\">
        <h3>";
            // line 160
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("value", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 160, $this->source); })()), " ---- ")) : (" ---- ")), "html", null, true);
            yield "</h3>
    </div>
</div>
";
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 165
    public function macro_viewButtonManager($__path__ = null, $__title__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "path" => $__path__,
            "title" => $__title__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "viewButtonManager"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "viewButtonManager"));

            // line 166
            yield "<div class=\"znv-full\">
    <div class=\"znv-buttons znv-go-right\">
        <a href=\"";
            // line 168
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["path"]) || array_key_exists("path", $context) ? $context["path"] : (function () { throw new RuntimeError('Variable "path" does not exist.', 168, $this->source); })()), "html", null, true);
            yield "\" class=\"znv-btn znv-sm znv-lightBlue\">
            <div class=\"znv-icon fa-cog\"></div>
            ";
            // line 170
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("title", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 170, $this->source); })()), "Manager")) : ("Manager")), "html", null, true);
            yield "
        </a>
    </div>
</div>
";
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 176
    public function macro_viewEmptyList($__text__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "text" => $__text__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "viewEmptyList"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "viewEmptyList"));

            // line 177
            yield "<div class=\"znv-list-empty\">
    <h4>";
            // line 178
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("text", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["text"]) || array_key_exists("text", $context) ? $context["text"] : (function () { throw new RuntimeError('Variable "text" does not exist.', 178, $this->source); })()), "List Empty")) : ("List Empty")), "html", null, true);
            yield "</h4>
</div>
";
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "global/macros.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  891 => 178,  888 => 177,  870 => 176,  853 => 170,  848 => 168,  844 => 166,  825 => 165,  809 => 160,  804 => 158,  801 => 157,  782 => 156,  767 => 152,  763 => 151,  760 => 150,  741 => 149,  726 => 145,  722 => 144,  719 => 143,  700 => 142,  683 => 136,  679 => 135,  675 => 134,  668 => 133,  665 => 132,  660 => 131,  658 => 130,  654 => 129,  631 => 128,  605 => 113,  599 => 109,  593 => 108,  589 => 107,  578 => 99,  568 => 92,  561 => 88,  555 => 85,  551 => 84,  538 => 77,  535 => 76,  513 => 75,  497 => 70,  494 => 69,  491 => 68,  473 => 67,  441 => 62,  436 => 61,  433 => 60,  430 => 59,  427 => 58,  424 => 57,  421 => 56,  418 => 55,  391 => 54,  365 => 49,  361 => 48,  356 => 47,  353 => 46,  350 => 45,  347 => 44,  344 => 43,  341 => 42,  338 => 41,  313 => 40,  296 => 36,  289 => 35,  286 => 34,  264 => 33,  249 => 29,  242 => 28,  239 => 27,  218 => 26,  203 => 22,  197 => 20,  179 => 19,  166 => 16,  160 => 14,  157 => 13,  148 => 11,  143 => 10,  141 => 9,  137 => 8,  131 => 6,  127 => 5,  123 => 4,  119 => 3,  117 => 2,  98 => 1,  87 => 183,  83 => 181,  80 => 175,  77 => 164,  74 => 155,  71 => 148,  68 => 141,  65 => 127,  62 => 74,  59 => 66,  56 => 53,  53 => 39,  50 => 32,  47 => 25,  44 => 18,);
    }

    public function getSourceContext()
    {
        return new Source("{% macro alertMessage(label, messages) %}
{% set alertColor = 'red' %}
{% if label == 'info' %}{% set alertColor = 'ligthBlue' %}{% endif %}
{% if label == 'warning' %}{% set alertColor = 'yellow' %}{% endif %}
{% if label == 'success' %}{% set alertColor = 'green' %}{% endif %}
<div class=\"znv-alert znv-{{ alertColor }} alert\" role=\"alert\">
    <button type=\"button\" class=\"znv-close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span></button>
    <strong>{{ ('flash.labels.'~ label)| trans({}, 'flashes') }}!</strong>
    {% if messages is iterable %}
        {% for message in messages %}
            {{ message |trans({}, 'flashes') | raw }} <br>
        {% endfor %}
    {% else %}
        {{ messages |trans({}, 'flashes') | raw }} <br>
    {% endif %}
</div>
{% endmacro alertMessage %}

{% macro buttonReturn(path) %}
    <a href=\"{{ path }}\" class=\"znv-btn\">
        <i class=\"fa-arrow-left\"></i>
        {{ 'form.buttons.return'|trans|upper }}
    </a>
{% endmacro buttonReturn %}

{% macro listActionButton(path, title, icon, roles) %}
    {% if (roles is not empty and app.user.hasRole(roles)) or roles is empty %}
        <a href=\"{{ path }}\" rel=\"tooltip\" data-placement=\"bottom\" data-original-title=\"{{ title|trans }}\"
               class=\"znv-icon {{ icon }}\"></a>
    {% endif %}
{% endmacro listActionButton %}

{% macro listActionButtonSpan(path, title, spanClass, spanText, roles) %}
    {% if (roles is not empty and app.user.hasRole(roles)) or roles is empty %}
        <a href=\"{{ path }}\" rel=\"tooltip\" data-placement=\"bottom\" data-original-title=\"{{ title|trans }}\">
        <span class=\"znv-label {{spanClass}}\">{{ spanText | trans | upper}}</span></a>
    {% endif %}
{% endmacro listActionButtonSpan %}

{% macro liConfirmButton(title, classIcon, roles, callback, modalId,selector, path, dataExtraBody) %}
    {% set selector = (selector == \"\") ? 'div.znv-line' : selector %}
    {% set modalId = (modalId == \"\") ? 'modalConfirm' : modalId %}
    {% set callback = (callback == \"\") ? 'undefined' : callback %}
    {% set path = (path == \"\") ? 'undefined' : path %}
    {% set dataExtraBody = (dataExtraBody == \"\") ? 'undefined' : dataExtraBody %}
    {% if (roles is not empty and app.user.hasRole(roles)) or roles is empty %}
            <button type=\"button\" data-rel=\"tooltip\" data-placement=\"top\" title=\"{{ title | trans }}\"
                    data-toggle=\"modal\" class=\"{{ classIcon }}\"
                    data-target=\"#{{ modalId }}\" onclick=\"show{{modalId}}(this, {{ callback }},'{{ selector }}', '{{path}}', '{{dataExtraBody}}')\">
            </button>
    {% endif %}
{% endmacro %}

{% macro liConfirmButtonComercio(title, color, action, text, roles, callback, modalId,selector, path, dataExtraBody) %}
    {% set selector = (selector == \"\") ? 'div.znv-line' : selector %}
    {% set modalId = (modalId == \"\") ? 'modalConfirm' : modalId %}
    {% set callback = (callback == \"\") ? 'undefined' : callback %}
    {% set path = (path == \"\") ? 'undefined' : path %}
    {% set dataExtraBody = (dataExtraBody == \"\") ? 'undefined' : dataExtraBody %}
    {% if (roles is not empty and app.user.hasRole(roles)) or roles is empty %}
        <button type=\"button\" data-rel=\"tooltip\" data-placement=\"top\" title=\"{{ title}}\"
                class=\"znv-btn\" data-toggle=\"modal\" data-target=\"#{{ modalId }}\" onclick=\"show{{modalId}}(this, {{ callback }},'{{ selector }}', '{{path}}', '{{dataExtraBody}}')\"><span class=\"znv-label {{ color }}\">{{ action }}</span> {{ text }}
        </button>
    {% endif %}
{% endmacro %}

{% macro listEmpty(totalEntitiesCount) %}
    {% if totalEntitiesCount == 0 %}
        <div class=\"boxListEmpty\">
            <p>{{ 'page.list.empty' | trans() | upper }}</p>
        </div>
    {% endif %}
{% endmacro %}

{% macro modal(label, body, icon, modalClass, id) %}
    {% set id = (id == \"\") ? 'modalConfirm' : id %}
    <div class=\"znv-modal {{modalClass}} in\" id=\"{{ id }}\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"delete\">
        <div class=\"znv-modal-dialog\" role=\"document\">
            <div class=\"znv-modal-content\">
                <div class=\"znv-modal-header\">
                    <button type=\"button\" class=\"znv-close\" data-dismiss=\"modal\">
                        <span aria-hidden=\"true\">×</span>
                    </button>
                    <div class=\"znv-icon {{ icon|default('fa-trash') }}\"></div>
                    <span class=\"js-modal-label\">{{ label|trans|raw }}</span>
                </div>
                <div class=\"znv-modal-body\">
                    <p class=\"js-modal-body\">{{ body|trans|raw }}<span class=\"js-modal-extra-body\"></span></p>
                </div>
                <div class=\"znv-modal-footer\">
                    <button type=\"button\" class=\"znv-btn znv-greyDark\" data-dismiss=\"modal\">
                        {{ 'form.buttons.cancel'|trans|upper }}
                        <div class=\"ripple-container\">
                            <div class=\"ripple ripple-on ripple-out\"
                                 style=\"left: 16.0313px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(10.375);\"></div>
                        </div>
                    </button>
                    <button type=\"submit\" class=\"znv-btn znv-greenDark js-modal-accept\">
                        {{ 'form.buttons.accept_modal'|trans|upper }}
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function show{{ id }}(button, callback, selector, path, dataExtraBody) {
            {%if selector is not defined  %} {% set selector = 'div.znv-line' %} {%endif%}
            if (typeof callback !== 'undefined') {
                callback(button);
            }

            var \$modal = \$('#{{ id }}');
            var \$button = \$(button);
            var \$div = \$button.parents(selector);
            if( path !== 'undefined'){
                \$path = path;
            }else{
                \$path = \$div.data('path');
            }
            \$modal.find('.js-modal-extra-body').html (' '+ dataExtraBody);
            \$modal.find('.js-modal-accept').click(function(){window.location=\$path});

        }
    </script>
{% endmacro modal %}

{% macro liNav(active, route, linkText, roles, icon, routeParams) %}
{% if routeParams is null %}{% set routeParams = {} %}{% endif %}
{% set classIcon = \"\" %}
    {% if icon is defined  and icon != \"\" %}{% set classIcon = \"znv-icon \"~icon %}{% endif %}
    {% if app.user.hasRole(roles) %}
        <li {% if(active) %} class=\"znv-active\" {% endif %}>
            <a href=\"{{ path(route, routeParams) }}\" class=\"znv-btn\">
                <div class=\"{{ classIcon }}\"></div>
                {{ linkText }}
            </a>
        </li>
    {% endif %}
{% endmacro %}

{% macro cardHalfView(text, value) %}
<div class=\"znv-form-group-view\">
    <p>{{ text }}</p>
    <h3>{{ value | default(' ---- ') }}</h3>
</div>
{% endmacro %}

{% macro viewHeaderFields(title, icon) %}
<div class=\"znv-widgets-header\">
    <div class=\"znv-icon {{ icon }}\"></div>
    <h3>{{ title }}</h3>
</div><!-- znv-widgets-header -->
{% endmacro %}

{% macro viewField(label, value) %}
<div class=\"znv-form-group-view\">
    <p>{{ label }}</p>
    <div class=\"znv-group\">
        <h3>{{ value | default(' ---- ') }}</h3>
    </div>
</div>
{% endmacro %}

{% macro viewButtonManager(path, title) %}
<div class=\"znv-full\">
    <div class=\"znv-buttons znv-go-right\">
        <a href=\"{{ path }}\" class=\"znv-btn znv-sm znv-lightBlue\">
            <div class=\"znv-icon fa-cog\"></div>
            {{ title|default('Manager') }}
        </a>
    </div>
</div>
{% endmacro  %}

{% macro viewEmptyList(text) %}
<div class=\"znv-list-empty\">
    <h4>{{ text | default('List Empty') }}</h4>
</div>
{% endmacro %}


{% import _self as macro %}
", "global/macros.html.twig", "C:\\Users\\lucia\\OneDrive\\Documentos\\GitHub\\jessica2020\\web\\templates\\global\\macros.html.twig");
    }
}
