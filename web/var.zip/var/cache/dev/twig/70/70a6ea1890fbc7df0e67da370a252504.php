<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* global/layout.html.twig */
class __TwigTemplate_88efff25625a03f0187a9548aa850b06 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 2
        $_trait_0 = $this->loadTemplate("global/_blocks.html.twig", "global/layout.html.twig", 2);
        if (!$_trait_0->unwrap()->isTraitable()) {
            throw new RuntimeError('Template "'."global/_blocks.html.twig".'" cannot be used as a trait.', 2, $this->source);
        }
        $_trait_0_blocks = $_trait_0->unwrap()->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            [
                'body' => [$this, 'block_body'],
                'buttonsTitle' => [$this, 'block_buttonsTitle'],
                'alertOutContent' => [$this, 'block_alertOutContent'],
                'znv_main_content' => [$this, 'block_znv_main_content'],
                'contentContainer' => [$this, 'block_contentContainer'],
                'alertMessages' => [$this, 'block_alertMessages'],
                'content' => [$this, 'block_content'],
                'blockFloatLeft' => [$this, 'block_blockFloatLeft'],
            ]
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "global/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/layout.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/layout.html.twig"));

        $this->parent = $this->loadTemplate("global/base.html.twig", "global/layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 4
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 5
        yield "<body>
        <div class=\"znv-page-overlay\"></div>

        ";
        // line 8
        yield from         $this->loadTemplate("global/_header.html.twig", "global/layout.html.twig", 8)->unwrap()->yield($context);
        // line 9
        yield "
        <section class=\"znv-panel-area\">
            <aside id=\"js-panel-primary\" class=\"znv-panel-primary\">
                <!-- User Session -->
                ";
        // line 13
        yield from         $this->loadTemplate("global/_user_section.html.twig", "global/layout.html.twig", 13)->unwrap()->yield($context);
        // line 14
        yield "                <!-- Nav -->
                ";
        // line 15
        yield from         $this->loadTemplate("global/_nav.html.twig", "global/layout.html.twig", 15)->unwrap()->yield($context);
        // line 16
        yield "            </aside>
        </section>
        <main>
            <div class=\"znv-main-header\">
                <div class=\"badge badge-success\">
                    <h5>";
        // line 21
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["titlePage"]) || array_key_exists("titlePage", $context) ? $context["titlePage"] : (function () { throw new RuntimeError('Variable "titlePage" does not exist.', 21, $this->source); })()), "html", null, true);
        yield "</h5>
                </div>
                <div class=\"znv-actions\">
                    <ul>
                        ";
        // line 25
        yield from $this->unwrap()->yieldBlock('buttonsTitle', $context, $blocks);
        // line 26
        yield "                    </ul>
                </div>
            </div>
            ";
        // line 29
        yield from $this->unwrap()->yieldBlock('alertOutContent', $context, $blocks);
        // line 30
        yield "            ";
        yield from $this->unwrap()->yieldBlock('znv_main_content', $context, $blocks);
        // line 50
        yield "        </main>";
        // line 52
        yield from         $this->loadTemplate("global/_footer.html.twig", "global/layout.html.twig", 52)->unwrap()->yield($context);
        // line 54
        yield "</body>";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 25
    public function block_buttonsTitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "buttonsTitle"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "buttonsTitle"));

        yield "";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 29
    public function block_alertOutContent($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "alertOutContent"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "alertOutContent"));

        yield "";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 30
    public function block_znv_main_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "znv_main_content"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "znv_main_content"));

        // line 31
        yield "                <div class=\"znv-main-content\">
                    <div class=\"znv-card-container ";
        // line 32
        if (array_key_exists("customStyleCard", $context)) {
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["customStyleCard"]) || array_key_exists("customStyleCard", $context) ? $context["customStyleCard"] : (function () { throw new RuntimeError('Variable "customStyleCard" does not exist.', 32, $this->source); })()), "html", null, true);
        }
        yield "\">
                       ";
        // line 33
        yield from $this->unwrap()->yieldBlock('contentContainer', $context, $blocks);
        // line 45
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('blockFloatLeft', $context, $blocks);
        // line 47
        yield "                    </div>
                </div>
            ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 33
    public function block_contentContainer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "contentContainer"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "contentContainer"));

        // line 34
        yield "                        <div class=\"znv-card-full\"><!--znv-flex-form-->
                            ";
        // line 35
        yield from $this->unwrap()->yieldBlock('alertMessages', $context, $blocks);
        // line 40
        yield "
                            ";
        // line 41
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 42
        yield "
                        </div>
                        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 35
    public function block_alertMessages($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "alertMessages"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "alertMessages"));

        // line 36
        yield "                                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 36, $this->source); })()), "flashes", [], "any", false, false, false, 36));
        foreach ($context['_seq'] as $context["label"] => $context["messages"]) {
            // line 37
            yield "                                    ";
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "alertMessage", [$context["label"], $context["messages"]]);
            yield "
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['label'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        yield "                            ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 41
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        yield "";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 45
    public function block_blockFloatLeft($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "blockFloatLeft"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "blockFloatLeft"));

        // line 46
        yield "                        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "global/layout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  324 => 46,  314 => 45,  294 => 41,  283 => 39,  274 => 37,  269 => 36,  259 => 35,  246 => 42,  244 => 41,  241 => 40,  239 => 35,  236 => 34,  226 => 33,  213 => 47,  210 => 45,  208 => 33,  202 => 32,  199 => 31,  189 => 30,  169 => 29,  149 => 25,  138 => 54,  136 => 52,  134 => 50,  131 => 30,  129 => 29,  124 => 26,  122 => 25,  115 => 21,  108 => 16,  106 => 15,  103 => 14,  101 => 13,  95 => 9,  93 => 8,  88 => 5,  78 => 4,  55 => 1,  29 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'global/base.html.twig' %}
{% use \"global/_blocks.html.twig\" %}

{%- block body -%}
    <body>
        <div class=\"znv-page-overlay\"></div>

        {% include \"global/_header.html.twig\" %}

        <section class=\"znv-panel-area\">
            <aside id=\"js-panel-primary\" class=\"znv-panel-primary\">
                <!-- User Session -->
                {% include \"global/_user_section.html.twig\" %}
                <!-- Nav -->
                {% include \"global/_nav.html.twig\" %}
            </aside>
        </section>
        <main>
            <div class=\"znv-main-header\">
                <div class=\"badge badge-success\">
                    <h5>{{ titlePage }}</h5>
                </div>
                <div class=\"znv-actions\">
                    <ul>
                        {% block buttonsTitle '' %}
                    </ul>
                </div>
            </div>
            {% block alertOutContent '' %}
            {% block znv_main_content %}
                <div class=\"znv-main-content\">
                    <div class=\"znv-card-container {% if customStyleCard is defined  %}{{ customStyleCard }}{% endif %}\">
                       {% block contentContainer %}
                        <div class=\"znv-card-full\"><!--znv-flex-form-->
                            {% block alertMessages %}
                                {% for label, messages in app.flashes %}
                                    {{ macro_alertMessage(label, messages) }}
                                {% endfor %}
                            {% endblock alertMessages %}

                            {% block content '' %}

                        </div>
                        {% endblock %}
                        {% block blockFloatLeft %}
                        {% endblock %}
                    </div>
                </div>
            {% endblock %}
        </main>

        {%- include 'global/_footer.html.twig' -%}

    </body>
{%- endblock body -%}
", "global/layout.html.twig", "C:\\Users\\lucia\\OneDrive\\Documentos\\GitHub\\jessica2020\\web\\templates\\global\\layout.html.twig");
    }
}
