<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* global/_nav.html.twig */
class __TwigTemplate_b113fe6328cd36b697f8d5523c8b76ae extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/_nav.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/_nav.html.twig"));

        // line 1
        if ( !array_key_exists("menu", $context)) {
            // line 2
            yield "    ";
            $context["menu"] = "";
        }
        // line 4
        yield "
";
        // line 5
        $context["rolesMenu"] = ["ROLE_USER_LIST", "ROLE_GROUP_LIST", "ROLE_ARTICULOS_LIST", "ROLE_CLIENTES_LIST", "ROLE_VENTAS_LIST", "ROLE_VENTAS_RECURRENTES", "ROLE_MARCAS_LIST", "ROLE_PRESUPUESTOS_LIST"];
        // line 6
        yield "
";
        // line 7
        $context["listMenu"] = [];
        // line 8
        yield "

<nav class=\"znv-nav\">
    <div class=\"znv-nav-section\">
        <h3>";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.menu.menu"), "html", null, true);
        yield "</h3>
        <ul>
            ";
        // line 14
        yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liNav", [((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 14, $this->source); })()) == "dashboard"), "home", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.dashboard.title"), ["ROLE_USER"], "fa-home"]);
        yield "
            ";
        // line 15
        if (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 15, $this->source); })()), "user", [], "any", false, false, false, 15), "isSuperAdmin", [], "any", false, false, false, 15)) {
            // line 16
            yield "                ";
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liNav", [((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 16, $this->source); })()) == "user"), "user_list", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.menu.user"), ["ROLE_USER_LIST"], "fa-user"]);
            yield "
                ";
            // line 17
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liNav", [((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 17, $this->source); })()) == "group"), "group_list", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.menu.group"), ["ROLE_GROUP_LIST"], "fa-users"]);
            yield "
                ";
            // line 18
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liNav", [((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 18, $this->source); })()) == "setting"), "setting_index", "Ajustes Masivos", [""], "fa-cog"]);
            yield "
            ";
        }
        // line 20
        yield "            <hr />
            ";
        // line 22
        yield "            ";
        if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 22, $this->source); })()), "user", [], "any", false, false, false, 22), "hasRole", [(isset($context["rolesMenu"]) || array_key_exists("rolesMenu", $context) ? $context["rolesMenu"] : (function () { throw new RuntimeError('Variable "rolesMenu" does not exist.', 22, $this->source); })())], "method", false, false, false, 22) || CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 22, $this->source); })()), "user", [], "any", false, false, false, 22), "isSuperAdmin", [], "any", false, false, false, 22))) {
            // line 23
            yield "                <li>
                    ";
            // line 24
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liNav", [((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 24, $this->source); })()) == "clientes"), "clientes_index", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.menu.clientes"), ["ROLE_CLIENTES_LIST"], "fa-list"]);
            yield "
                </li>
                <li>
                    ";
            // line 27
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liNav", [((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 27, $this->source); })()) == "marcas"), "marcas_index", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.menu.marcas"), ["ROLE_MARCAS_LIST"], "fa-list"]);
            yield "
                </li>
                <li>
                    ";
            // line 30
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liNav", [((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 30, $this->source); })()) == "articulos"), "articulos_index", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.menu.articulos"), ["ROLE_ARTICULOS_LIST"], "fa-list-alt"]);
            yield "
                </li>
                <hr />
                <li>
                    ";
            // line 34
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liNav", [((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 34, $this->source); })()) == "ventas"), "ventas_index", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.menu.ventas"), ["ROLE_VENTAS_LIST"], "fa fa-shopping-cart"]);
            yield "
                    ";
            // line 35
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liNav", [((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 35, $this->source); })()) == "ventas_recurrentes"), "venta_recurrentes_new", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.menu.ventas_recurrentes"), ["ROLE_VENTAS_RECURRENTES"], "fa fa-money"]);
            yield "
                </li>
                 <hr />
                <li>
                    ";
            // line 39
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liNav", [((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 39, $this->source); })()) == "presupuestos"), "presupuestos_index", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.menu.presupuestos"), ["ROLE_PRESUPUESTOS_LIST"], "fa fa-shopping-cart"]);
            yield "
                </li>
                <hr />               
                ";
            // line 42
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liNav", [((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 42, $this->source); })()) == "informes"), "informes_tipo", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.menu.informesTipo"), ["ROLE_INFORMES"], "fa-list"]);
            yield "  
            ";
        }
        // line 44
        yield "        </ul>

    </div><!-- znv-nav-section -->
</nav>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "global/_nav.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  141 => 44,  136 => 42,  130 => 39,  123 => 35,  119 => 34,  112 => 30,  106 => 27,  100 => 24,  97 => 23,  94 => 22,  91 => 20,  86 => 18,  82 => 17,  77 => 16,  75 => 15,  71 => 14,  66 => 12,  60 => 8,  58 => 7,  55 => 6,  53 => 5,  50 => 4,  46 => 2,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% if menu is not defined %}
    {% set menu = \"\" %}
{% endif %}

{% set rolesMenu = ['ROLE_USER_LIST', 'ROLE_GROUP_LIST', 'ROLE_ARTICULOS_LIST', 'ROLE_CLIENTES_LIST', 'ROLE_VENTAS_LIST', 'ROLE_VENTAS_RECURRENTES', 'ROLE_MARCAS_LIST', 'ROLE_PRESUPUESTOS_LIST'] %}

{% set listMenu =  [] %}


<nav class=\"znv-nav\">
    <div class=\"znv-nav-section\">
        <h3>{{ 'page.menu.menu'|trans }}</h3>
        <ul>
            {{ macro_liNav((menu == \"dashboard\"), 'home', 'page.dashboard.title'|trans, ['ROLE_USER'], 'fa-home') }}
            {% if app.user.isSuperAdmin %}
                {{ macro_liNav((menu == \"user\"), 'user_list', 'page.menu.user'|trans, ['ROLE_USER_LIST'], 'fa-user') }}
                {{ macro_liNav((menu == \"group\"), 'group_list', 'page.menu.group'|trans, ['ROLE_GROUP_LIST'], 'fa-users') }}
                {{ macro_liNav((menu == \"setting\"), 'setting_index', 'Ajustes Masivos', [''], 'fa-cog') }}
            {% endif %}
            <hr />
            {# PARA EL USUARIO COMUN #}
            {% if app.user.hasRole(rolesMenu) or app.user.isSuperAdmin %}
                <li>
                    {{ macro_liNav((menu == \"clientes\"), 'clientes_index', 'page.menu.clientes'|trans, ['ROLE_CLIENTES_LIST'], 'fa-list') }}
                </li>
                <li>
                    {{ macro_liNav((menu == \"marcas\"), 'marcas_index', 'page.menu.marcas'|trans, ['ROLE_MARCAS_LIST'], 'fa-list') }}
                </li>
                <li>
                    {{ macro_liNav((menu == \"articulos\"), 'articulos_index', 'page.menu.articulos'|trans, ['ROLE_ARTICULOS_LIST'], 'fa-list-alt') }}
                </li>
                <hr />
                <li>
                    {{ macro_liNav((menu == \"ventas\"), 'ventas_index', 'page.menu.ventas'|trans, ['ROLE_VENTAS_LIST'], 'fa fa-shopping-cart') }}
                    {{ macro_liNav((menu == \"ventas_recurrentes\"), 'venta_recurrentes_new', 'page.menu.ventas_recurrentes'|trans, ['ROLE_VENTAS_RECURRENTES'], 'fa fa-money') }}
                </li>
                 <hr />
                <li>
                    {{ macro_liNav((menu == \"presupuestos\"), 'presupuestos_index', 'page.menu.presupuestos'|trans, ['ROLE_PRESUPUESTOS_LIST'], 'fa fa-shopping-cart') }}
                </li>
                <hr />               
                {{ macro_liNav((menu == \"informes\"), 'informes_tipo', 'page.menu.informesTipo'|trans, ['ROLE_INFORMES'], 'fa-list') }}  
            {% endif %}
        </ul>

    </div><!-- znv-nav-section -->
</nav>
", "global/_nav.html.twig", "C:\\Users\\lucia\\OneDrive\\Documentos\\GitHub\\jessica2020\\web\\templates\\global\\_nav.html.twig");
    }
}
