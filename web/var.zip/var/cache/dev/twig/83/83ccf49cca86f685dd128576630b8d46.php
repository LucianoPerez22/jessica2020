<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* global/_blocks.html.twig */
class __TwigTemplate_c2530c34138f0bf013f3b44421316857 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'alertContainer' => [$this, 'block_alertContainer'],
            'alertContainerMessages' => [$this, 'block_alertContainerMessages'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/_blocks.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/_blocks.html.twig"));

        // line 1
        yield from $this->unwrap()->yieldBlock('alertContainer', $context, $blocks);
        // line 52
        yield "
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 1
    public function block_alertContainer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "alertContainer"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "alertContainer"));

        // line 2
        yield "    ";
        if ( !array_key_exists("alertContainerId", $context)) {
            // line 3
            yield "        ";
            $context["alertContainerId"] = "alert-container";
            // line 4
            yield "    ";
        }
        // line 5
        yield "    ";
        if ( !array_key_exists("alertIsDismissible", $context)) {
            // line 6
            yield "        ";
            $context["alertIsDismissible"] = true;
            // line 7
            yield "    ";
        }
        // line 8
        yield "    <div class=\"znv-alert ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("alertColor", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["alertColor"]) || array_key_exists("alertColor", $context) ? $context["alertColor"] : (function () { throw new RuntimeError('Variable "alertColor" does not exist.', 8, $this->source); })()), "znv-red")) : ("znv-red")), "html", null, true);
        yield " alert\" role=\"alert\" id=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["alertContainerId"]) || array_key_exists("alertContainerId", $context) ? $context["alertContainerId"] : (function () { throw new RuntimeError('Variable "alertContainerId" does not exist.', 8, $this->source); })()), "html", null, true);
        yield "\"
         style=\"";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("alertContainerStyle", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["alertContainerStyle"]) || array_key_exists("alertContainerStyle", $context) ? $context["alertContainerStyle"] : (function () { throw new RuntimeError('Variable "alertContainerStyle" does not exist.', 9, $this->source); })()), "")) : ("")), "html", null, true);
        yield "\">
        <button type=\"button\"
                class=\"znv-close\" ";
        // line 11
        if (((isset($context["alertIsDismissible"]) || array_key_exists("alertIsDismissible", $context) ? $context["alertIsDismissible"] : (function () { throw new RuntimeError('Variable "alertIsDismissible" does not exist.', 11, $this->source); })()) == true)) {
            yield " data-dismiss=\"alert\" ";
        }
        yield ">
            <span aria-hidden=\"true\" onclick=\"onClickCloseAlert()\">×</span>
        </button>
        ";
        // line 14
        yield from $this->unwrap()->yieldBlock('alertContainerMessages', $context, $blocks);
        // line 24
        yield "    </div>
    <script>
        var \$alertContainer = \$('#";
        // line 26
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["alertContainerId"]) || array_key_exists("alertContainerId", $context) ? $context["alertContainerId"] : (function () { throw new RuntimeError('Variable "alertContainerId" does not exist.', 26, $this->source); })()), "html", null, true);
        yield "');
        var \$alertMessagesContainer = \$('#alert-messages-container ul');


        function onClickCloseAlert() {
            \$alertContainer.hide();
        }

        function hideAlertContainer() {
            \$alertContainer.hide();
        }

        function showAlertContainer() {
            \$alertContainer.show();
        }

        function removeAlertMessagesContainerChildren() {
            \$alertMessagesContainer.children().remove();
        }

        function addMessageToAlert(message) {
            \$alertMessagesContainer.append(\"<li>\" + message + \"</li>\");
            showAlertContainer();
        }
    </script>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 14
    public function block_alertContainerMessages($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "alertContainerMessages"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "alertContainerMessages"));

        // line 15
        yield "            <strong>";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::titleCase($this->env->getCharset(), ((array_key_exists("alertContainerLabel", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["alertContainerLabel"]) || array_key_exists("alertContainerLabel", $context) ? $context["alertContainerLabel"] : (function () { throw new RuntimeError('Variable "alertContainerLabel" does not exist.', 15, $this->source); })()), "")) : (""))), "html", null, true);
        yield "</strong>
            <div id=\"alert-messages-container\">
                <ul>
                    ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("messages", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["messages"]) || array_key_exists("messages", $context) ? $context["messages"] : (function () { throw new RuntimeError('Variable "messages" does not exist.', 18, $this->source); })()), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 19
            yield "                        <li>";
            yield $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["message"], [], "flashes");
            yield "</li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        yield "                </ul>
            </div>
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "global/_blocks.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  181 => 21,  172 => 19,  168 => 18,  161 => 15,  151 => 14,  114 => 26,  110 => 24,  108 => 14,  100 => 11,  95 => 9,  88 => 8,  85 => 7,  82 => 6,  79 => 5,  76 => 4,  73 => 3,  70 => 2,  60 => 1,  48 => 52,  46 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% block alertContainer %}
    {% if alertContainerId is not defined %}
        {% set alertContainerId = 'alert-container' %}
    {% endif %}
    {% if alertIsDismissible is not defined %}
        {% set alertIsDismissible = true %}
    {% endif %}
    <div class=\"znv-alert {{ alertColor|default('znv-red') }} alert\" role=\"alert\" id=\"{{ alertContainerId }}\"
         style=\"{{ alertContainerStyle|default('') }}\">
        <button type=\"button\"
                class=\"znv-close\" {% if alertIsDismissible == true %} data-dismiss=\"alert\" {% endif %}>
            <span aria-hidden=\"true\" onclick=\"onClickCloseAlert()\">×</span>
        </button>
        {% block alertContainerMessages %}
            <strong>{{ alertContainerLabel|default('')|title }}</strong>
            <div id=\"alert-messages-container\">
                <ul>
                    {% for message in messages|default([]) %}
                        <li>{{ message |trans({}, 'flashes') | raw }}</li>
                    {% endfor %}
                </ul>
            </div>
        {% endblock %}
    </div>
    <script>
        var \$alertContainer = \$('#{{ alertContainerId }}');
        var \$alertMessagesContainer = \$('#alert-messages-container ul');


        function onClickCloseAlert() {
            \$alertContainer.hide();
        }

        function hideAlertContainer() {
            \$alertContainer.hide();
        }

        function showAlertContainer() {
            \$alertContainer.show();
        }

        function removeAlertMessagesContainerChildren() {
            \$alertMessagesContainer.children().remove();
        }

        function addMessageToAlert(message) {
            \$alertMessagesContainer.append(\"<li>\" + message + \"</li>\");
            showAlertContainer();
        }
    </script>
{% endblock %}

", "global/_blocks.html.twig", "C:\\Users\\lucia\\OneDrive\\Documentos\\GitHub\\jessica2020\\web\\templates\\global\\_blocks.html.twig");
    }
}
