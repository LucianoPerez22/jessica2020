<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* form/custom_types.html.twig */
class __TwigTemplate_927a0515197b26c927207cec0a518526 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'custom_grouped_choices_widget' => [$this, 'block_custom_grouped_choices_widget'],
            'custom_single_checkbox_widget' => [$this, 'block_custom_single_checkbox_widget'],
            'custom_from_and_to_datetime_widget' => [$this, 'block_custom_from_and_to_datetime_widget'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "form/custom_types.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "form/custom_types.html.twig"));

        // line 1
        yield from $this->unwrap()->yieldBlock('custom_grouped_choices_widget', $context, $blocks);
        // line 47
        yield from $this->unwrap()->yieldBlock('custom_single_checkbox_widget', $context, $blocks);
        // line 58
        yield from $this->unwrap()->yieldBlock('custom_from_and_to_datetime_widget', $context, $blocks);
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 1
    public function block_custom_grouped_choices_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "custom_grouped_choices_widget"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "custom_grouped_choices_widget"));

        // line 3
        yield "<div class=\"znv-collapse\">
    ";
        // line 4
        $context["index"] = 0;
        // line 5
        yield "    ";
        $context["children"] = CoreExtension::getAttribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 5, $this->source); })()), "children", [], "any", false, false, false, 5);
        // line 6
        yield "
    ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 7, $this->source); })()), "vars", [], "any", false, false, false, 7), "choices", [], "any", false, false, false, 7));
        foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
            // line 8
            yield "    <button type=\"button\" class=\"znv-btn\" data-toggle=\"collapse\" data-target=\"#fgroup";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new RuntimeError('Variable "index" does not exist.', 8, $this->source); })()), "html", null, true);
            yield "\" aria-expanded=\"false\"
            aria-controls=\"fgroup";
            // line 9
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new RuntimeError('Variable "index" does not exist.', 9, $this->source); })()), "html", null, true);
            yield "\">
        ";
            // line 10
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["role"], "label", [], "any", false, false, false, 10), "html", null, true);
            yield "
        <div class=\"znv-icon fa-chevron-left\"></div>
    </button>
    <div class=\"znv-group collapse\" id=\"fgroup";
            // line 13
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new RuntimeError('Variable "index" does not exist.', 13, $this->source); })()), "html", null, true);
            yield "\">
        <div class=\"znv-checkbox znv-full\">
            <label>
                <input type=\"checkbox\" data-rol-group=\"";
            // line 16
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace(Twig\Extension\CoreExtension::lower($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, $context["role"], "label", [], "any", false, false, false, 16)), [" " => "-"]), "html", null, true);
            yield "\"
                       class=\"js-all-choices\">
                <span class=\"znv-label\">";
            // line 18
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("form.choices.all"), "html", null, true);
            yield "</span>
            </label>
        </div>
        <hr>
        ";
            // line 22
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["role"], "choices", [], "any", false, false, false, 22));
            foreach ($context['_seq'] as $context["key"] => $context["rol"]) {
                // line 23
                yield "            <div class=\"znv-checkbox znv-small\">
                <label>
                    ";
                // line 25
                yield $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 25, $this->source); })()), $context["key"], [], "array", false, false, false, 25), 'widget', ["attr" => ["class" => ("js-role-" . Twig\Extension\CoreExtension::replace(Twig\Extension\CoreExtension::lower($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, $context["role"], "label", [], "any", false, false, false, 25)), [" " => "-"]))]]);
                yield "
                    <span class=\"znv-checkbox-material\"><span class=\"check\"></span></span>
                    <span class=\"znv-label\">";
                // line 27
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["rol"], "label", [], "any", false, false, false, 27), "html", null, true);
                yield "</span>
                </label>
            </div>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['rol'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 31
            yield "    </div>
        ";
            // line 32
            $context["index"] = ((isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new RuntimeError('Variable "index" does not exist.', 32, $this->source); })()) + 1);
            // line 33
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        yield "</div>

<script>
    \$(\".js-all-choices\").off('change.roleSelectAll')
        .on('change.roleSelectAll', function () {
            var \$input = \$(this);
            var checked = \$input.is(\":checked\");
            var label = \$input.data(\"rol-group\");
            \$('.js-role-' + label).prop(\"checked\", checked);
        });
</script>";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 47
    public function block_custom_single_checkbox_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "custom_single_checkbox_widget"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "custom_single_checkbox_widget"));

        // line 48
        yield "<div class=\"znv-togglebutton\">
        <label>
            <span class=\"znv-label\">";
        // line 50
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 50, $this->source); })()), "vars", [], "any", false, false, false, 50), "false_choice", [], "any", false, false, false, 50)), "html", null, true);
        yield "</span>
            ";
        // line 51
        yield $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 51, $this->source); })()), 'widget');
        yield "
            <span class=\"toggle\"></span>
            <span class=\"znv-label\">";
        // line 53
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 53, $this->source); })()), "vars", [], "any", false, false, false, 53), "true_choice", [], "any", false, false, false, 53)), "html", null, true);
        yield "</span>
        </label>
    </div>";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 58
    public function block_custom_from_and_to_datetime_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "custom_from_and_to_datetime_widget"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "custom_from_and_to_datetime_widget"));

        // line 59
        yield $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 59, $this->source); })()), "from", [], "any", false, false, false, 59), 'row');
        yield "
    ";
        // line 60
        yield $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 60, $this->source); })()), "to", [], "any", false, false, false, 60), 'row');
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "form/custom_types.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  226 => 60,  222 => 59,  212 => 58,  198 => 53,  193 => 51,  189 => 50,  185 => 48,  175 => 47,  154 => 34,  148 => 33,  146 => 32,  143 => 31,  133 => 27,  128 => 25,  124 => 23,  120 => 22,  113 => 18,  108 => 16,  102 => 13,  96 => 10,  92 => 9,  87 => 8,  83 => 7,  80 => 6,  77 => 5,  75 => 4,  72 => 3,  62 => 1,  51 => 58,  49 => 47,  47 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- block custom_grouped_choices_widget -%}

<div class=\"znv-collapse\">
    {% set index = 0 %}
    {% set children = form.children %}

    {% for role in form.vars.choices %}
    <button type=\"button\" class=\"znv-btn\" data-toggle=\"collapse\" data-target=\"#fgroup{{ index }}\" aria-expanded=\"false\"
            aria-controls=\"fgroup{{ index }}\">
        {{ role.label }}
        <div class=\"znv-icon fa-chevron-left\"></div>
    </button>
    <div class=\"znv-group collapse\" id=\"fgroup{{ index }}\">
        <div class=\"znv-checkbox znv-full\">
            <label>
                <input type=\"checkbox\" data-rol-group=\"{{ role.label | lower | replace({' ': '-'}) }}\"
                       class=\"js-all-choices\">
                <span class=\"znv-label\">{{ 'form.choices.all' | trans }}</span>
            </label>
        </div>
        <hr>
        {% for key, rol in role.choices %}
            <div class=\"znv-checkbox znv-small\">
                <label>
                    {{ form_widget(form[key], {'attr' : {'class' : 'js-role-' ~ role.label| lower | replace({' ': '-'}) }}) }}
                    <span class=\"znv-checkbox-material\"><span class=\"check\"></span></span>
                    <span class=\"znv-label\">{{ rol.label }}</span>
                </label>
            </div>
        {% endfor %}
    </div>
        {% set index = index + 1 %}
    {% endfor %}
</div>

<script>
    \$(\".js-all-choices\").off('change.roleSelectAll')
        .on('change.roleSelectAll', function () {
            var \$input = \$(this);
            var checked = \$input.is(\":checked\");
            var label = \$input.data(\"rol-group\");
            \$('.js-role-' + label).prop(\"checked\", checked);
        });
</script>
{%- endblock -%}

{%- block custom_single_checkbox_widget -%}
    <div class=\"znv-togglebutton\">
        <label>
            <span class=\"znv-label\">{{ form.vars.false_choice | trans }}</span>
            {{ form_widget(form) }}
            <span class=\"toggle\"></span>
            <span class=\"znv-label\">{{ form.vars.true_choice | trans }}</span>
        </label>
    </div>
{%- endblock -%}

{%- block custom_from_and_to_datetime_widget -%}
    {{ form_row(form.from) }}
    {{ form_row(form.to) }}
{%- endblock -%}
", "form/custom_types.html.twig", "C:\\Users\\lucia\\OneDrive\\Documentos\\GitHub\\jessica2020\\web\\templates\\form\\custom_types.html.twig");
    }
}
