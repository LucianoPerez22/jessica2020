<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* ventas/index.html.twig */
class __TwigTemplate_afd4b1ac3a224933d4bff8a7fd1ed6e7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'list' => [$this, 'block_list'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "global/layout_list.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "ventas/index.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "ventas/index.html.twig"));

        // line 3
        $context["titlePage"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.ventas.title.list");
        // line 4
        $context["menu"] = "ventas";
        // line 6
        $context["formFilterAction"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ventas_index");
        // line 7
        $context["pathNew"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("venta_new");
        // line 8
        $context["labelButtonNew"] = "page.ventas.buttons.add";
        // line 9
        $context["rolesNew"] = ["ROLE_VENTAS_NEW"];
        // line 1
        $this->parent = $this->loadTemplate("global/layout_list.html.twig", "ventas/index.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 11
    public function block_list($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "list"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "list"));

        // line 12
        yield "    <div class=\"znv-header\">    
        <div class=\"znv-col\"> Cliente
        </div>       
        <div class=\"znv-col\"> Tipo
        </div>       
        <div class=\"znv-col\"> Fecha
        </div>       
        <div class=\"znv-col\"> Total
        </div>       
       
        <div class=\"znv-col-actions\">
        </div>
    </div>    

    ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["entities"]) || array_key_exists("entities", $context) ? $context["entities"] : (function () { throw new RuntimeError('Variable "entities" does not exist.', 26, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["ventas"]) {
            // line 27
            yield "        <div class=\"znv-line\" data-path=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ventas_delete", ["id" => CoreExtension::getAttribute($this->env, $this->source, $context["ventas"], "id", [], "any", false, false, false, 27)]), "html", null, true);
            yield "\" data-name=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["ventas"], "id", [], "any", false, false, false, 27), "html", null, true);
            yield "\">
            <div class=\"znv-col\">
                <div class=\"znv-header\">Cliente:</div>
                    ";
            // line 30
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["ventas"], "idCliente", [], "any", false, false, false, 30), "nombre", [], "any", false, false, false, 30), "html", null, true);
            yield "
            </div>    
            <div class=\"znv-col\">
                <div class=\"znv-header\">Tipo:</div>
                    ";
            // line 34
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["ventas"], "tipo", [], "any", false, false, false, 34), "html", null, true);
            yield "
            </div>          
            <div class=\"znv-col\">
                <div class=\"znv-header\">Fecha:</div>
                    ";
            // line 38
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate(CoreExtension::getAttribute($this->env, $this->source, $context["ventas"], "fecha", [], "any", false, false, false, 38), "d-m-Y"), "html", null, true);
            yield "
            </div>    
            <div class=\"znv-col\">
                <div class=\"znv-header\">Total:</div>
                    ";
            // line 42
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber(CoreExtension::getAttribute($this->env, $this->source, $context["ventas"], "total", [], "any", false, false, false, 42), 2, ",", "."), "html", null, true);
            yield "
            </div>             
            <div class=\"znv-col-actions\">
                <div class=\"znv-group\">                                        
                    ";
            // line 46
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "listActionButton", [$this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("venta_show", ["id" => CoreExtension::getAttribute($this->env, $this->source, $context["ventas"], "id", [], "any", false, false, false, 46)]), "page.list.buttons.view", "fa-eye", ["ROLE_VENTAS_VIEW"]]);
            yield "                    
                    ";
            // line 47
            yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "liConfirmButton", ["page.list.buttons.delete", "znv-icon fa-trash", ["ROLE_VENTAS_DELETE"], "setNameAndText"]);
            yield " 
                </div>
            </div>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ventas'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        yield "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "ventas/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  154 => 52,  143 => 47,  139 => 46,  132 => 42,  125 => 38,  118 => 34,  111 => 30,  102 => 27,  98 => 26,  82 => 12,  72 => 11,  61 => 1,  59 => 9,  57 => 8,  55 => 7,  53 => 6,  51 => 4,  49 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'global/layout_list.html.twig' %}

{% set titlePage = \"page.ventas.title.list\" | trans %}
{% set menu = \"ventas\" %}

{% set formFilterAction = path('ventas_index') %}
{% set pathNew = path('venta_new') %}
{% set labelButtonNew = 'page.ventas.buttons.add' %}
{% set rolesNew = ['ROLE_VENTAS_NEW'] %}

{% block list %}
    <div class=\"znv-header\">    
        <div class=\"znv-col\"> Cliente
        </div>       
        <div class=\"znv-col\"> Tipo
        </div>       
        <div class=\"znv-col\"> Fecha
        </div>       
        <div class=\"znv-col\"> Total
        </div>       
       
        <div class=\"znv-col-actions\">
        </div>
    </div>    

    {% for ventas in entities %}
        <div class=\"znv-line\" data-path=\"{{ path('ventas_delete', { 'id' : ventas.id }) }}\" data-name=\"{{ ventas.id }}\">
            <div class=\"znv-col\">
                <div class=\"znv-header\">Cliente:</div>
                    {{ventas.idCliente.nombre}}
            </div>    
            <div class=\"znv-col\">
                <div class=\"znv-header\">Tipo:</div>
                    {{ventas.tipo}}
            </div>          
            <div class=\"znv-col\">
                <div class=\"znv-header\">Fecha:</div>
                    {{ventas.fecha|date('d-m-Y') }}
            </div>    
            <div class=\"znv-col\">
                <div class=\"znv-header\">Total:</div>
                    {{ventas.total | number_format(2, ',', '.')}}
            </div>             
            <div class=\"znv-col-actions\">
                <div class=\"znv-group\">                                        
                    {{ macro_listActionButton(path('venta_show', {'id' : ventas.id}), 'page.list.buttons.view', 'fa-eye', ['ROLE_VENTAS_VIEW']) }}                    
                    {{ macro_liConfirmButton('page.list.buttons.delete', 'znv-icon fa-trash', ['ROLE_VENTAS_DELETE'], 'setNameAndText') }} 
                </div>
            </div>
        </div>
    {% endfor %}

{% endblock list %}
", "ventas/index.html.twig", "C:\\Users\\lucia\\OneDrive\\Documentos\\GitHub\\jessica2020\\web\\templates\\ventas\\index.html.twig");
    }
}
