<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* global/layout_list.html.twig */
class __TwigTemplate_a099d686ca203e5220afe06f596d8af4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'buttonsTitle' => [$this, 'block_buttonsTitle'],
            'buttonNew' => [$this, 'block_buttonNew'],
            'content' => [$this, 'block_content'],
            'formFilter' => [$this, 'block_formFilter'],
            'formContent' => [$this, 'block_formContent'],
            'header_block' => [$this, 'block_header_block'],
            'list' => [$this, 'block_list'],
            'pagination' => [$this, 'block_pagination'],
            'modalDelete' => [$this, 'block_modalDelete'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "global/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/layout_list.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/layout_list.html.twig"));

        // line 3
        $context["classForm"] = ((array_key_exists("classForm", $context)) ? ((isset($context["classForm"]) || array_key_exists("classForm", $context) ? $context["classForm"] : (function () { throw new RuntimeError('Variable "classForm" does not exist.', 3, $this->source); })())) : ("znv-form-inline"));
        // line 4
        $context["formFilterAction"] = ((array_key_exists("formFilterAction", $context)) ? ((isset($context["formFilterAction"]) || array_key_exists("formFilterAction", $context) ? $context["formFilterAction"] : (function () { throw new RuntimeError('Variable "formFilterAction" does not exist.', 4, $this->source); })())) : ($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 4, $this->source); })()), "request", [], "any", false, false, false, 4), "attributes", [], "any", false, false, false, 4), "get", ["_route"], "method", false, false, false, 4), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 4, $this->source); })()), "request", [], "any", false, false, false, 4), "attributes", [], "any", false, false, false, 4), "get", ["_route_params"], "method", false, false, false, 4))));
        // line 5
        $context["formMethod"] = ((array_key_exists("formMethod", $context)) ? ((isset($context["formMethod"]) || array_key_exists("formMethod", $context) ? $context["formMethod"] : (function () { throw new RuntimeError('Variable "formMethod" does not exist.', 5, $this->source); })())) : ("GET"));
        // line 6
        $context["labelButtonNew"] = ((array_key_exists("labelButtonNew", $context)) ? ((isset($context["labelButtonNew"]) || array_key_exists("labelButtonNew", $context) ? $context["labelButtonNew"] : (function () { throw new RuntimeError('Variable "labelButtonNew" does not exist.', 6, $this->source); })())) : ("page.list.buttons.add"));
        // line 7
        $context["rolesNew"] = ((array_key_exists("rolesNew", $context)) ? ((isset($context["rolesNew"]) || array_key_exists("rolesNew", $context) ? $context["rolesNew"] : (function () { throw new RuntimeError('Variable "rolesNew" does not exist.', 7, $this->source); })())) : (false));
        // line 1
        $this->parent = $this->loadTemplate("global/layout.html.twig", "global/layout_list.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 9
    public function block_buttonsTitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "buttonsTitle"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "buttonsTitle"));

        // line 10
        yield "    ";
        yield from $this->unwrap()->yieldBlock('buttonNew', $context, $blocks);
        // line 20
        yield "    ";
        if ((((isset($context["rolesNew"]) || array_key_exists("rolesNew", $context) ? $context["rolesNew"] : (function () { throw new RuntimeError('Variable "rolesNew" does not exist.', 20, $this->source); })()) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 20, $this->source); })()), "user", [], "any", false, false, false, 20), "hasRole", [(isset($context["rolesNew"]) || array_key_exists("rolesNew", $context) ? $context["rolesNew"] : (function () { throw new RuntimeError('Variable "rolesNew" does not exist.', 20, $this->source); })())], "method", false, false, false, 20)) && ((array_key_exists("form", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 20, $this->source); })()), null)) : (null)))) {
            // line 21
            yield "        <li class=\"divider\"></li>
    ";
        }
        // line 23
        yield "    ";
        if (((array_key_exists("form", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 23, $this->source); })()), null)) : (null))) {
            // line 24
            yield "      <li>
        <button type=\"button\" id=\"js-btn-filter\" class=\"znv-btn js-active collapsed\" data-toggle=\"collapse\"
                data-target=\"#js-filter\" aria-expanded=\"false\" aria-controls=\"js-filter\">
            <div class=\"znv-icon fa-filter\"></div>
            ";
            // line 28
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("form.buttons.filter"), "html", null, true);
            yield "
        </button>
      </li>
    ";
        }
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 10
    public function block_buttonNew($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "buttonNew"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "buttonNew"));

        // line 11
        yield "        ";
        if (((isset($context["rolesNew"]) || array_key_exists("rolesNew", $context) ? $context["rolesNew"] : (function () { throw new RuntimeError('Variable "rolesNew" does not exist.', 11, $this->source); })()) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 11, $this->source); })()), "user", [], "any", false, false, false, 11), "hasRole", [(isset($context["rolesNew"]) || array_key_exists("rolesNew", $context) ? $context["rolesNew"] : (function () { throw new RuntimeError('Variable "rolesNew" does not exist.', 11, $this->source); })())], "method", false, false, false, 11))) {
            // line 12
            yield "            <li>
                <a href=\"";
            // line 13
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["pathNew"]) || array_key_exists("pathNew", $context) ? $context["pathNew"] : (function () { throw new RuntimeError('Variable "pathNew" does not exist.', 13, $this->source); })()), "html", null, true);
            yield "\" class=\"znv-btn\">
                    <div class=\"znv-icon fa-plus\"></div>
                    ";
            // line 15
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["labelButtonNew"]) || array_key_exists("labelButtonNew", $context) ? $context["labelButtonNew"] : (function () { throw new RuntimeError('Variable "labelButtonNew" does not exist.', 15, $this->source); })())), "html", null, true);
            yield "
                </a>
            </li>
        ";
        }
        // line 19
        yield "    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 34
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 35
        yield "    ";
        yield from $this->unwrap()->yieldBlock('formFilter', $context, $blocks);
        // line 70
        yield "
    <div class=\"znv-card\">
        ";
        // line 72
        yield from $this->unwrap()->yieldBlock('header_block', $context, $blocks);
        // line 73
        yield "        <div class=\"znv-card-body\">
            <div class=\"znv-list-container znv-striped\">
                ";
        // line 75
        yield from $this->unwrap()->yieldBlock('list', $context, $blocks);
        // line 76
        yield "            </div>
            ";
        // line 77
        yield from $this->unwrap()->yieldBlock('pagination', $context, $blocks);
        // line 82
        yield "        </div>
    </div>

    ";
        // line 85
        yield from $this->unwrap()->yieldBlock('modalDelete', $context, $blocks);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 35
    public function block_formFilter($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "formFilter"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "formFilter"));

        // line 36
        yield "        <div class=\"collapse znv-box-filter\" id=\"js-filter\" aria-expanded=\"true\">
            ";
        // line 37
        yield         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 37, $this->source); })()), 'form_start', ["action" => (isset($context["formFilterAction"]) || array_key_exists("formFilterAction", $context) ? $context["formFilterAction"] : (function () { throw new RuntimeError('Variable "formFilterAction" does not exist.', 37, $this->source); })()), "method" => (isset($context["formMethod"]) || array_key_exists("formMethod", $context) ? $context["formMethod"] : (function () { throw new RuntimeError('Variable "formMethod" does not exist.', 37, $this->source); })()), "attr" => ["class" =>         // line 38
(isset($context["classForm"]) || array_key_exists("classForm", $context) ? $context["classForm"] : (function () { throw new RuntimeError('Variable "classForm" does not exist.', 38, $this->source); })()), "novalidate" => "novalidate"]]);
        yield "
            ";
        // line 39
        yield from $this->unwrap()->yieldBlock('formContent', $context, $blocks);
        // line 53
        yield "            <div class=\"znv-form-group znv-form-action\">
                <button type=\"submit\" class=\"znv-btn znv-greenDark\" name=\"filter\" value=\"filter\">
                    ";
        // line 55
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::upper($this->env->getCharset(), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("form.buttons.apply")), "html", null, true);
        yield "
                </button>
                <button type=\"button\" class=\"znv-btn znv-greyDark\" onclick=\"cleanFilters(this);\" value=\"reset\">
                    ";
        // line 58
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::upper($this->env->getCharset(), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("form.buttons.clean")), "html", null, true);
        yield "
                </button>
            </div>
            ";
        // line 61
        yield         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 61, $this->source); })()), 'form_end');
        yield "
        </div>
        <script type=\"text/javascript\">
            function cleanFilters(button) {
                \$(button).parents('form').attr('method', 'POST');
                \$(button).parents('form').submit();
            }
        </script>
    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 39
    public function block_formContent($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "formContent"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "formContent"));

        // line 40
        yield "                ";
        $context["filtered"] = false;
        // line 41
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 41, $this->source); })()), "children", [], "any", false, false, false, 41));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 42
            yield "                    ";
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["child"], "vars", [], "any", false, false, false, 42), "value", [], "any", false, false, false, 42)) > 0)) {
                // line 43
                yield "                        ";
                $context["filtered"] = true;
                // line 44
                yield "                    ";
            }
            // line 45
            yield "                    ";
            yield $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'row');
            yield "
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        yield "                ";
        if ((isset($context["filtered"]) || array_key_exists("filtered", $context) ? $context["filtered"] : (function () { throw new RuntimeError('Variable "filtered" does not exist.', 47, $this->source); })())) {
            // line 48
            yield "                    <script type=\"text/javascript\">
                        \$('#js-btn-filter').addClass('znv-yellow');
                    </script>
                ";
        }
        // line 52
        yield "            ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 72
    public function block_header_block($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "header_block"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "header_block"));

        yield "";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 75
    public function block_list($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "list"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "list"));

        yield "";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 77
    public function block_pagination($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "pagination"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "pagination"));

        // line 78
        yield "                ";
        if (((isset($context["totalEntitiesCount"]) || array_key_exists("totalEntitiesCount", $context) ? $context["totalEntitiesCount"] : (function () { throw new RuntimeError('Variable "totalEntitiesCount" does not exist.', 78, $this->source); })()) > 0)) {
            // line 79
            yield "                    ";
            yield $this->extensions['Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension']->render($this->env, (isset($context["entities"]) || array_key_exists("entities", $context) ? $context["entities"] : (function () { throw new RuntimeError('Variable "entities" does not exist.', 79, $this->source); })()), "global/_pagination.html.twig");
            yield "
                ";
        }
        // line 81
        yield "            ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 85
    public function block_modalDelete($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "modalDelete"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "modalDelete"));

        // line 86
        yield "        ";
        yield $this->extensions['App\Twig\MacroAutoloadTwigExtension']->twig_render_macro($this->env, $context, "modal", ["page.common.confirm.delete_record", "page.common.confirm.ask_continue", "fa-trash", "modalRed"]);
        yield "

        <script>
            function setNameAndText(button) {

                var \$modal = \$('#modalConfirm');
                var \$button = \$(button);
                var \$div = \$button.parents('div.znv-line');
                var text = '";
        // line 94
        yield $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.common.confirm.ask_continue");
        yield "';

                text = text.replace('%name%', \$div.data('name'));
                \$modal.find('.js-modal-body').html(text);
            }
        </script>


    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "global/layout_list.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  412 => 94,  400 => 86,  390 => 85,  379 => 81,  373 => 79,  370 => 78,  360 => 77,  340 => 75,  320 => 72,  309 => 52,  303 => 48,  300 => 47,  291 => 45,  288 => 44,  285 => 43,  282 => 42,  277 => 41,  274 => 40,  264 => 39,  244 => 61,  238 => 58,  232 => 55,  228 => 53,  226 => 39,  222 => 38,  221 => 37,  218 => 36,  208 => 35,  197 => 85,  192 => 82,  190 => 77,  187 => 76,  185 => 75,  181 => 73,  179 => 72,  175 => 70,  172 => 35,  162 => 34,  151 => 19,  144 => 15,  139 => 13,  136 => 12,  133 => 11,  123 => 10,  107 => 28,  101 => 24,  98 => 23,  94 => 21,  91 => 20,  88 => 10,  78 => 9,  67 => 1,  65 => 7,  63 => 6,  61 => 5,  59 => 4,  57 => 3,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'global/layout.html.twig' %}

{% set classForm = classForm is defined ? classForm : 'znv-form-inline' %}
{% set formFilterAction = formFilterAction is defined ? formFilterAction : path(app.request.attributes.get('_route'), app.request.attributes.get('_route_params')) %}
{% set formMethod = formMethod is defined ? formMethod : 'GET' %}
{% set labelButtonNew = labelButtonNew is defined ? labelButtonNew : 'page.list.buttons.add' %}
{% set rolesNew = rolesNew is defined ? rolesNew : false %}

{% block buttonsTitle %}
    {% block buttonNew %}
        {% if rolesNew and app.user.hasRole(rolesNew) %}
            <li>
                <a href=\"{{ pathNew }}\" class=\"znv-btn\">
                    <div class=\"znv-icon fa-plus\"></div>
                    {{ labelButtonNew|trans }}
                </a>
            </li>
        {% endif %}
    {% endblock %}
    {% if rolesNew and app.user.hasRole(rolesNew) and form|default(null) %}
        <li class=\"divider\"></li>
    {% endif %}
    {% if form|default(null) %}
      <li>
        <button type=\"button\" id=\"js-btn-filter\" class=\"znv-btn js-active collapsed\" data-toggle=\"collapse\"
                data-target=\"#js-filter\" aria-expanded=\"false\" aria-controls=\"js-filter\">
            <div class=\"znv-icon fa-filter\"></div>
            {{ 'form.buttons.filter'|trans }}
        </button>
      </li>
    {% endif %}
{% endblock %}

{% block content %}
    {% block formFilter %}
        <div class=\"collapse znv-box-filter\" id=\"js-filter\" aria-expanded=\"true\">
            {{ form_start(form, {'action': formFilterAction, 'method': formMethod,
                'attr': {'class': classForm, 'novalidate': 'novalidate' }}) }}
            {% block formContent %}
                {% set filtered = false %}
                {% for child in form.children %}
                    {% if child.vars.value|length > 0  %}
                        {% set filtered = true %}
                    {% endif %}
                    {{ form_row(child) }}
                {% endfor %}
                {% if filtered %}
                    <script type=\"text/javascript\">
                        \$('#js-btn-filter').addClass('znv-yellow');
                    </script>
                {% endif %}
            {% endblock formContent %}
            <div class=\"znv-form-group znv-form-action\">
                <button type=\"submit\" class=\"znv-btn znv-greenDark\" name=\"filter\" value=\"filter\">
                    {{ 'form.buttons.apply'|trans()|upper }}
                </button>
                <button type=\"button\" class=\"znv-btn znv-greyDark\" onclick=\"cleanFilters(this);\" value=\"reset\">
                    {{ 'form.buttons.clean'|trans()|upper }}
                </button>
            </div>
            {{ form_end(form) }}
        </div>
        <script type=\"text/javascript\">
            function cleanFilters(button) {
                \$(button).parents('form').attr('method', 'POST');
                \$(button).parents('form').submit();
            }
        </script>
    {% endblock %}

    <div class=\"znv-card\">
        {% block header_block '' %}
        <div class=\"znv-card-body\">
            <div class=\"znv-list-container znv-striped\">
                {% block list '' %}
            </div>
            {% block pagination %}
                {% if totalEntitiesCount > 0 %}
                    {{ knp_pagination_render(entities,'global/_pagination.html.twig') }}
                {% endif %}
            {% endblock pagination %}
        </div>
    </div>

    {% block modalDelete %}
        {{ macro_modal('page.common.confirm.delete_record', 'page.common.confirm.ask_continue', 'fa-trash', 'modalRed' ) }}

        <script>
            function setNameAndText(button) {

                var \$modal = \$('#modalConfirm');
                var \$button = \$(button);
                var \$div = \$button.parents('div.znv-line');
                var text = '{{ 'page.common.confirm.ask_continue' | trans | raw }}';

                text = text.replace('%name%', \$div.data('name'));
                \$modal.find('.js-modal-body').html(text);
            }
        </script>


    {% endblock %}
{% endblock content %}
", "global/layout_list.html.twig", "C:\\Users\\lucia\\OneDrive\\Documentos\\GitHub\\jessica2020\\web\\templates\\global\\layout_list.html.twig");
    }
}
