<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* global/_pagination.html.twig */
class __TwigTemplate_9b8b35c4506c3e0a41783962f0239065 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/_pagination.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/_pagination.html.twig"));

        // line 1
        yield "<div class=\"znv-list-footer\">
    <div class=\"znv-selector\">
        <p>
            ";
        // line 4
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.list.pagination.show"), "html", null, true);
        yield "
        </p>
        <div class=\"znv-form-group is-empty\">
            ";
        // line 7
        $context["options"] = ["10", "25", "50", "100"];
        // line 8
        yield "            <select id=\"js-znv-select-limit\" class=\"znv-form-control\">
                ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 9, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["option"]) {
            // line 10
            yield "                    <option value=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["option"], "html", null, true);
            yield "\" ";
            if (($context["option"] == CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 10, $this->source); })()), "session", [], "any", false, false, false, 10), "get", ["limit"], "method", false, false, false, 10))) {
                yield " selected ";
            }
            yield " >";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["option"], "html", null, true);
            yield "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['option'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 12
        yield "            </select>
        </div>
        <p>";
        // line 14
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.list.pagination.records"), "html", null, true);
        yield "</p>
        ";
        // line 15
        $context["params"] = ["limit" => "placeholder"];
        // line 16
        yield "        ";
        if (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 16, $this->source); })()), "request", [], "any", false, false, false, 16), "attributes", [], "any", false, false, false, 16), "get", ["_route_params"], "method", false, false, false, 16))) {
            // line 17
            yield "            ";
            $context["routeParams"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 17, $this->source); })()), "request", [], "any", false, false, false, 17), "attributes", [], "any", false, false, false, 17), "get", ["_route_params"], "method", false, false, false, 17);
            // line 18
            yield "            ";
            $context["params"] = Twig\Extension\CoreExtension::merge((isset($context["params"]) || array_key_exists("params", $context) ? $context["params"] : (function () { throw new RuntimeError('Variable "params" does not exist.', 18, $this->source); })()), (isset($context["routeParams"]) || array_key_exists("routeParams", $context) ? $context["routeParams"] : (function () { throw new RuntimeError('Variable "routeParams" does not exist.', 18, $this->source); })()));
            // line 19
            yield "        ";
        }
        // line 20
        yield "        <script type=\"text/javascript\">
            \$(\"#js-znv-select-limit\").change(function () {
                var route = \"";
        // line 22
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath((isset($context["route"]) || array_key_exists("route", $context) ? $context["route"] : (function () { throw new RuntimeError('Variable "route" does not exist.', 22, $this->source); })()), (isset($context["params"]) || array_key_exists("params", $context) ? $context["params"] : (function () { throw new RuntimeError('Variable "params" does not exist.', 22, $this->source); })())), "html", null, true);
        yield "\";
                window.location = route.replace(\"placeholder\", \$(this).val());
            });
        </script>
    </div><!-- znv-pagination -->
    <div class=\"znv-pagination\">
        <ul>
            ";
        // line 29
        if (((isset($context["current"]) || array_key_exists("current", $context) ? $context["current"] : (function () { throw new RuntimeError('Variable "current" does not exist.', 29, $this->source); })()) > 1)) {
            // line 30
            yield "                <li>
                    <a href=\"";
            // line 31
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath((isset($context["route"]) || array_key_exists("route", $context) ? $context["route"] : (function () { throw new RuntimeError('Variable "route" does not exist.', 31, $this->source); })()), Twig\Extension\CoreExtension::merge((isset($context["query"]) || array_key_exists("query", $context) ? $context["query"] : (function () { throw new RuntimeError('Variable "query" does not exist.', 31, $this->source); })()), [(isset($context["pageParameterName"]) || array_key_exists("pageParameterName", $context) ? $context["pageParameterName"] : (function () { throw new RuntimeError('Variable "pageParameterName" does not exist.', 31, $this->source); })()) => 1])), "html", null, true);
            yield "\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.list.pagination.firstPage"), "html", null, true);
            yield "</a>
                </li>
            ";
        } else {
            // line 34
            yield "                <li class=\"\">
                    <span>";
            // line 35
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.list.pagination.firstPage"), "html", null, true);
            yield "</span>
                </li>
            ";
        }
        // line 38
        yield "            ";
        if (array_key_exists("previous", $context)) {
            // line 39
            yield "                <li>
                    <a href=\"";
            // line 40
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath((isset($context["route"]) || array_key_exists("route", $context) ? $context["route"] : (function () { throw new RuntimeError('Variable "route" does not exist.', 40, $this->source); })()), Twig\Extension\CoreExtension::merge((isset($context["query"]) || array_key_exists("query", $context) ? $context["query"] : (function () { throw new RuntimeError('Variable "query" does not exist.', 40, $this->source); })()), [(isset($context["pageParameterName"]) || array_key_exists("pageParameterName", $context) ? $context["pageParameterName"] : (function () { throw new RuntimeError('Variable "pageParameterName" does not exist.', 40, $this->source); })()) => (isset($context["previous"]) || array_key_exists("previous", $context) ? $context["previous"] : (function () { throw new RuntimeError('Variable "previous" does not exist.', 40, $this->source); })())])), "html", null, true);
            yield "\">
                        <i class=\"fa-chevron-left\"></i>
                    </a>
                </li>
            ";
        } else {
            // line 45
            yield "                <li class=\"\">
                    <span>
                        <i class=\"fa-chevron-left\"></i>
                    </span>
                </li>
            ";
        }
        // line 51
        yield "            ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["pagesInRange"]) || array_key_exists("pagesInRange", $context) ? $context["pagesInRange"] : (function () { throw new RuntimeError('Variable "pagesInRange" does not exist.', 51, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["page"]) {
            // line 52
            yield "                ";
            if (($context["page"] != (isset($context["current"]) || array_key_exists("current", $context) ? $context["current"] : (function () { throw new RuntimeError('Variable "current" does not exist.', 52, $this->source); })()))) {
                // line 53
                yield "                    <li class=\"znv-active\">
                        <a href=\"";
                // line 54
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath((isset($context["route"]) || array_key_exists("route", $context) ? $context["route"] : (function () { throw new RuntimeError('Variable "route" does not exist.', 54, $this->source); })()), Twig\Extension\CoreExtension::merge((isset($context["query"]) || array_key_exists("query", $context) ? $context["query"] : (function () { throw new RuntimeError('Variable "query" does not exist.', 54, $this->source); })()), [(isset($context["pageParameterName"]) || array_key_exists("pageParameterName", $context) ? $context["pageParameterName"] : (function () { throw new RuntimeError('Variable "pageParameterName" does not exist.', 54, $this->source); })()) => $context["page"]])), "html", null, true);
                yield "\">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["page"], "html", null, true);
                yield "</a>
                    </li>
                ";
            } else {
                // line 57
                yield "                    <li class=\"znv-active\">
                        <span>";
                // line 58
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["page"], "html", null, true);
                yield "</span>
                    </li>
                ";
            }
            // line 61
            yield "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['page'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 62
        yield "            ";
        if (array_key_exists("next", $context)) {
            // line 63
            yield "                <li>
                    <a href=\"";
            // line 64
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath((isset($context["route"]) || array_key_exists("route", $context) ? $context["route"] : (function () { throw new RuntimeError('Variable "route" does not exist.', 64, $this->source); })()), Twig\Extension\CoreExtension::merge((isset($context["query"]) || array_key_exists("query", $context) ? $context["query"] : (function () { throw new RuntimeError('Variable "query" does not exist.', 64, $this->source); })()), [(isset($context["pageParameterName"]) || array_key_exists("pageParameterName", $context) ? $context["pageParameterName"] : (function () { throw new RuntimeError('Variable "pageParameterName" does not exist.', 64, $this->source); })()) => (isset($context["next"]) || array_key_exists("next", $context) ? $context["next"] : (function () { throw new RuntimeError('Variable "next" does not exist.', 64, $this->source); })())])), "html", null, true);
            yield "\">
                        <i class=\"fa-chevron-right\"></i>
                    </a>
                </li>
            ";
        } else {
            // line 69
            yield "                <li class=\"\">
                    <span>
                        <i class=\"fa-chevron-right\"></i>
                    </span>
                </li>
            ";
        }
        // line 75
        yield "            ";
        if (((isset($context["pageCount"]) || array_key_exists("pageCount", $context) ? $context["pageCount"] : (function () { throw new RuntimeError('Variable "pageCount" does not exist.', 75, $this->source); })()) > (isset($context["current"]) || array_key_exists("current", $context) ? $context["current"] : (function () { throw new RuntimeError('Variable "current" does not exist.', 75, $this->source); })()))) {
            // line 76
            yield "                <li>
                    <a href=\"";
            // line 77
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath((isset($context["route"]) || array_key_exists("route", $context) ? $context["route"] : (function () { throw new RuntimeError('Variable "route" does not exist.', 77, $this->source); })()), Twig\Extension\CoreExtension::merge((isset($context["query"]) || array_key_exists("query", $context) ? $context["query"] : (function () { throw new RuntimeError('Variable "query" does not exist.', 77, $this->source); })()), [(isset($context["pageParameterName"]) || array_key_exists("pageParameterName", $context) ? $context["pageParameterName"] : (function () { throw new RuntimeError('Variable "pageParameterName" does not exist.', 77, $this->source); })()) => (isset($context["pageCount"]) || array_key_exists("pageCount", $context) ? $context["pageCount"] : (function () { throw new RuntimeError('Variable "pageCount" does not exist.', 77, $this->source); })())])), "html", null, true);
            yield "\">
                        ";
            // line 78
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.list.pagination.lastPage"), "html", null, true);
            yield "</a>
                </li>
            ";
        } else {
            // line 81
            yield "                <li class=\"\">
                    <span>";
            // line 82
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("page.list.pagination.lastPage"), "html", null, true);
            yield "</span>
                </li>
            ";
        }
        // line 85
        yield "        </ul>
    </div>
</div>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "global/_pagination.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  240 => 85,  234 => 82,  231 => 81,  225 => 78,  221 => 77,  218 => 76,  215 => 75,  207 => 69,  199 => 64,  196 => 63,  193 => 62,  187 => 61,  181 => 58,  178 => 57,  170 => 54,  167 => 53,  164 => 52,  159 => 51,  151 => 45,  143 => 40,  140 => 39,  137 => 38,  131 => 35,  128 => 34,  120 => 31,  117 => 30,  115 => 29,  105 => 22,  101 => 20,  98 => 19,  95 => 18,  92 => 17,  89 => 16,  87 => 15,  83 => 14,  79 => 12,  64 => 10,  60 => 9,  57 => 8,  55 => 7,  49 => 4,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"znv-list-footer\">
    <div class=\"znv-selector\">
        <p>
            {{ 'page.list.pagination.show'|trans }}
        </p>
        <div class=\"znv-form-group is-empty\">
            {% set options = ['10','25','50','100'] %}
            <select id=\"js-znv-select-limit\" class=\"znv-form-control\">
                {% for option in options %}
                    <option value=\"{{ option }}\" {% if (option == app.session.get('limit')) %} selected {% endif %} >{{ option }}</option>
                {% endfor %}
            </select>
        </div>
        <p>{{ 'page.list.pagination.records'|trans }}</p>
        {% set params = {\"limit\": \"placeholder\"} %}
        {% if app.request.attributes.get('_route_params')| length %}
            {% set routeParams = app.request.attributes.get('_route_params') %}
            {% set params = (params|merge(routeParams)) %}
        {% endif %}
        <script type=\"text/javascript\">
            \$(\"#js-znv-select-limit\").change(function () {
                var route = \"{{ path(route, params) }}\";
                window.location = route.replace(\"placeholder\", \$(this).val());
            });
        </script>
    </div><!-- znv-pagination -->
    <div class=\"znv-pagination\">
        <ul>
            {% if current > 1 %}
                <li>
                    <a href=\"{{ path(route, query|merge({ (pageParameterName): 1 })) }}\">{{ 'page.list.pagination.firstPage'|trans() }}</a>
                </li>
            {% else %}
                <li class=\"\">
                    <span>{{ 'page.list.pagination.firstPage'|trans }}</span>
                </li>
            {% endif %}
            {% if previous is defined %}
                <li>
                    <a href=\"{{ path(route, query|merge({ (pageParameterName): previous })) }}\">
                        <i class=\"fa-chevron-left\"></i>
                    </a>
                </li>
            {% else %}
                <li class=\"\">
                    <span>
                        <i class=\"fa-chevron-left\"></i>
                    </span>
                </li>
            {% endif %}
            {% for page in pagesInRange %}
                {% if page != current %}
                    <li class=\"znv-active\">
                        <a href=\"{{ path(route, query|merge({(pageParameterName): page})) }}\">{{ page }}</a>
                    </li>
                {% else %}
                    <li class=\"znv-active\">
                        <span>{{ page }}</span>
                    </li>
                {% endif %}
            {% endfor %}
            {% if next is defined %}
                <li>
                    <a href=\"{{ path(route, query|merge({(pageParameterName): next})) }}\">
                        <i class=\"fa-chevron-right\"></i>
                    </a>
                </li>
            {% else %}
                <li class=\"\">
                    <span>
                        <i class=\"fa-chevron-right\"></i>
                    </span>
                </li>
            {% endif %}
            {% if pageCount > current %}
                <li>
                    <a href=\"{{ path(route, query|merge({(pageParameterName): pageCount})) }}\">
                        {{ 'page.list.pagination.lastPage'|trans }}</a>
                </li>
            {% else %}
                <li class=\"\">
                    <span>{{ 'page.list.pagination.lastPage'|trans }}</span>
                </li>
            {% endif %}
        </ul>
    </div>
</div>
", "global/_pagination.html.twig", "C:\\Users\\lucia\\OneDrive\\Documentos\\GitHub\\jessica2020\\web\\templates\\global\\_pagination.html.twig");
    }
}
