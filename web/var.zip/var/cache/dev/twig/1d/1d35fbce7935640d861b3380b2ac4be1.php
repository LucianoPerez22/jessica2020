<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* global/_header.html.twig */
class __TwigTemplate_1a38a67288856d8318a46869432a3af8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/_header.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "global/_header.html.twig"));

        // line 1
        yield "<header>
    <!-- Toggle Nav -->
    <div class=\"znv-navbutton-toggle\">
        <button id=\"js-nav-trigger\" class=\"znv-nav-trigger\" type=\"button\">
            <span class=\"znv-nav-icon\"></span>
        </button>
    </div>
    <!-- Logo -->
    <div class=\"znv-logo\">
        <a href=\"";
        // line 10
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\" class=\"znv-brand btn\">
            <figure>
                <img src=\"\" alt=\"\">
            </figure>
        </a>
    </div>
  ";
        // line 16
        if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 16, $this->source); })()), "user", [], "any", false, false, false, 16), "hasRole", [["ROLE_MESSAGE_LIST_RECIEVED"]], "method", false, false, false, 16) &&  !CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 16, $this->source); })()), "user", [], "any", false, false, false, 16), "isSuperAdmin", [], "any", false, false, false, 16))) {
            // line 17
            yield "    <div class=\"znv-toolbar\">
        <div class=\"znv-notifications \">
            <ul>
                <li class=\"znv-icons\">
                    <a href=\"";
            // line 21
            yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("message_received");
            yield "\" class=\"znv-btn\" rel=\"tooltip\" data-placement=\"bottom\" data-original-title=\"Message\">
                        <div class=\"znv-icon fa-envelope\"></div>
                        <span class=\"badge\" id=\"messageNotification\"></span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
      <script>
          \$( document ).ready(function() {
              \$.get('";
            // line 31
            yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("message_unread");
            yield "', function (data) {
                    if(data.quantity > 0){
                        \$('#messageNotification').text(data.quantity);
                    }
              });
          });
      </script>
    ";
        }
        // line 39
        yield "</header>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "global/_header.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  96 => 39,  85 => 31,  72 => 21,  66 => 17,  64 => 16,  55 => 10,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<header>
    <!-- Toggle Nav -->
    <div class=\"znv-navbutton-toggle\">
        <button id=\"js-nav-trigger\" class=\"znv-nav-trigger\" type=\"button\">
            <span class=\"znv-nav-icon\"></span>
        </button>
    </div>
    <!-- Logo -->
    <div class=\"znv-logo\">
        <a href=\"{{ path('home') }}\" class=\"znv-brand btn\">
            <figure>
                <img src=\"\" alt=\"\">
            </figure>
        </a>
    </div>
  {% if app.user.hasRole(['ROLE_MESSAGE_LIST_RECIEVED']) and not app.user.isSuperAdmin %}
    <div class=\"znv-toolbar\">
        <div class=\"znv-notifications \">
            <ul>
                <li class=\"znv-icons\">
                    <a href=\"{{ path('message_received') }}\" class=\"znv-btn\" rel=\"tooltip\" data-placement=\"bottom\" data-original-title=\"Message\">
                        <div class=\"znv-icon fa-envelope\"></div>
                        <span class=\"badge\" id=\"messageNotification\"></span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
      <script>
          \$( document ).ready(function() {
              \$.get('{{ path('message_unread') }}', function (data) {
                    if(data.quantity > 0){
                        \$('#messageNotification').text(data.quantity);
                    }
              });
          });
      </script>
    {% endif %}
</header>
", "global/_header.html.twig", "C:\\Users\\lucia\\OneDrive\\Documentos\\GitHub\\jessica2020\\web\\templates\\global\\_header.html.twig");
    }
}
